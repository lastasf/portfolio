<?php
    require "var/var.php";
    require "var/varmodel3.php";
    require "title.php";
    $title = "$model3Title";
    $description = "$model3Description";
    $headerClass = "header-other-pages";
    $mainPage = "/";
    require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/elco-ho-tron"> одноступ.</a><span class="px-1">/</span></li>
                        <li><?=$model3?></li>
                    </ul>
                </div>
            </div>
        </div>        
       
    </div>
</section>

<section>
    <div class="container">        

        <!--Third-level-catalogue-1-->
        <div class="third-level-catalogue-1">
            <div class="my-4">
                <h1><?=$h1Model?> <?=$model3?></h1>
                <div class="line-for-header"></div>
            </div>

            <div class="row">
                <div class="col-lg-4">                    
                    <div class="text-center">
                        <img class="img-fluid" src="img/products/<?=$imgmodel3?>.jpg" alt="<?=$h1Model?> <?=$model3?>">
                    </div>                                     
                </div>
                <div class="col-lg-8 mt-3 px-lg-5">                    
                    <h3>Описание <?=$descriptionModelH3?> <?=$model3?></h3>
                    <p><?=$descriptionModel?></p>
                    <h3>Характеристики <?=$descriptionModelH3?> <?=$model3?></h3>
                    <?=$characteristics?>
                    <div class="row mt-2 mb-3">
                        <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    </div>
                </div>
            </div>

            <hr> 

            <div class="my-5">
                <h2><?=$h1Model?>:</h2>
                <?=$navigation?>
            </div>

            <hr>

            <div class="row my-5"> 
                <div class="col-md-12">
                    <h2 class="mb-5">Рабочий диапазон мощности <?=$descriptionModelH3?> <?=$model3?></h2>
                     <img class="img-fluid" src="img/r-d/<?=$imgmodel3?>.png" alt="<?=$h1Model?> <?=$model3?>">
                </div>
            </div>

            <hr>

            <div class="row my-5"> 
                <div class="col-md-12">
                    <h2 class="mb-5">Размеры <?=$descriptionModelH3?> <?=$model3?></h2>
                    <img class="img-fluid" src="img/size/<?=$imgmodel3?>.png" alt="<?=$h1Model?> <?=$model3?>">
                </div>
            </div>             
            
        </div>       
        <!--End of third-level-catalogue-1-->

    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	