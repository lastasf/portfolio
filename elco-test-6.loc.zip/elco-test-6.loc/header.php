<!DOCTYPE html>
<html lang="ru">
<head>
	<meta charset="UTF-8">	
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="<?=$description?>"/>	
	<title><?=$title?></title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
	<link rel="stylesheet" href="css/style.css">	
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
    <link rel="icon" href="img/favicon.ico" type="image/x-icon">
	<link rel="shortcut icon" type="image/png" href="img/favicon.png">		
	<script src="js/jquery-3.1.0.min.js"></script>	
</head>
<body>	
	<div class="loader">
		<div class="laoder-frame">
			<img class="svg-loader" src="img/loader.svg" alt="">
		</div>
	</div>	

	<!-- Header -->
	<header>
		<div id="backToTop" class="top-header <?=$headerClass?>">
			<div class="container">
				<div class="top-header-content"> 
					<span class="top-header-text"> 
	                    <i class="fa fa-phone-square"> </i><span><a href="tel:+74951315749"> 8 (495)131-57-49</a></span>
	                    <i class="fa fa-envelope"> </i><span><a href="mailto:gtksnab@mail.ru"> gtksnab@mail.ru</a></span>
	                    <i class="fa fa-clock-o"> </i><span> Пн-Чт: 09:00 - 18:00, Пт: 09:00 - 17:00</span>
	                </span>
				</div>
			</div>
		</div>
		
		<div class="bottom-header <?=$headerClass?>">
			<div class="container">
				<div class="row">
					<div class="col-2">
						 <div class="logo">
                            <a href="/">
                                <img src="img/logo1.png" alt="logo" class="img-fluid logotip">
                            </a>
                        </div>    
					</div>
					<div class="col-8 col-lg-4">
						<div class="tel-and-mail">
                            <span style="padding-right:8px;"><i class="fa fa-phone-square"> </i> <a href="tel:+74951315749"> 8(495)131-57-49</a></span>
                            <span><i class="fa fa-envelope"> </i><a href="mailto:gtksnab@mail.ru"> gtksnab@mail.ru</a></span>
                        </div>
					</div>
					<div class="col-2 col-lg-6">
						<nav>
							<span id="trigram">&#9776;</span>
							<div class="nav nav-close">
                                <ul>                                	
                                    <li><a href="/">ГЛАВНАЯ</a></li>
									<li><a href="<?=$mainPage?>#catalogue">КАТАЛОГ</a></li>									
                                    <li><a href="<?=$mainPage?>#product">О ПРОДУКТЕ</a></li>                                    
                                    <li><a href="<?=$mainPage?>#contacts">КОНТАКТЫ</a></li>									
                                </ul>
                            </div>
						</nav>
					</div>					
				</div>
			</div>
		</div>
	</header>
	<!-- End of Header -->