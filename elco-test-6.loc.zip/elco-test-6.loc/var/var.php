<?php

$model1 = "HO-TRON 0.135";
$model2 = "HO-TRON 0.225";
$model3 = "HO-TRON 1.350";

$model4 = "HO-TRON 1.350 Z";
$model5 = "HO-TRON 2.580 Z";
$model6 = "HO-TRON 2.930 Z";
$model7 = "HO-TRON 2.1400 Z";
$model8 = "HO-TRON 3.1700 Z";
$model9 = "HO-TRON 3.2100 Z";
$model10 = "HO-TRON 4.3000 Z";
$model11 = "HO-TRON 4.3900 Z3";

$model12 = "HO-TRON 4.3000 R";
$model13 = "HO-TRON 4.3900 R";
$model14 = "HO-TRON 5.5000 R";
$model15 = "HO-TRON 5.5800 R";
$model16 = "HO-TRON 6.7200 R";
$model17 = "HO-TRON 6.8500 R";
$model18 = "HO-TRON 6.10500 R";
$model19 = "HO-TRON 6.13000 R";
$model20 = "HO-TRON 7.15000 R";
$model21 = "HO-TRON 7.17000 R";

$imgmodel1 = "elco-ho-tron-0-135";
$imgmodel2 = "elco-ho-tron-0-225";
$imgmodel3 = "elco-ho-tron-1-350";

$imgmodel4 = "elco-ho-tron-1-350-z";
$imgmodel5 = "elco-ho-tron-2-580-z";
$imgmodel6 = "elco-ho-tron-2-930-z";
$imgmodel7 = "elco-ho-tron-2-1400-z";
$imgmodel8 = "elco-ho-tron-3-1700-z";
$imgmodel9 = "elco-ho-tron-3-2100-z";
$imgmodel10 = "elco-ho-tron-4-3000-z";
$imgmodel11 = "elco-ho-tron-4-3900-z3";

$imgmodel12 = "elco-ho-tron-4-3000-r";
$imgmodel13 = "elco-ho-tron-4-3900-r";
$imgmodel14 = "elco-ho-tron-5-5000-r";
$imgmodel15 = "elco-ho-tron-5-5800-r";
$imgmodel16 = "elco-ho-tron-6-7200-r";
$imgmodel17 = "elco-ho-tron-6-8500-r";
$imgmodel18 = "elco-ho-tron-6-10500-r";
$imgmodel19 = "elco-ho-tron-6-13000-r";
$imgmodel20 = "elco-ho-tron-7-15000-r";
$imgmodel21 = "elco-ho-tron-7-17000-r";

$h1Model = "Моноблочные горелки ELCO";
$descriptionModelH3 = "моноблочных горелок ELCO";

$navigation = '
<p class="a-black mb-1">Одноступенчатые: <span class="font-weight-bold" style="font-size:0.8rem;">	
	<a href="'.$imgmodel1.'">'.$model1.'</a>
	<a href="'.$imgmodel2.'">'.$model2.'</a>
	<a href="'.$imgmodel3.'">'.$model3.'</a>	
</span></p>
<p class="a-black mb-1">Двухступенчатые: <span class="font-weight-bold" style="font-size:0.8rem;">	
	<a href="'.$imgmodel4.'">'.$model4.'</a>,
	<a href="'.$imgmodel5.'">'.$model5.'</a>,
	<a href="'.$imgmodel6.'">'.$model6.'</a>,
	<a href="'.$imgmodel7.'">'.$model7.'</a>,
	<a href="'.$imgmodel8.'">'.$model8.'</a>,
	<a href="'.$imgmodel9.'">'.$model9.'</a>,
	<a href="'.$imgmodel10.'">'.$model10.'</a>,
	<a href="'.$imgmodel11.'">'.$model11.'</a>,
</span></p>
<p class="a-black mb-1">Плавно-двухступенчатые: <span class="font-weight-bold" style="font-size:0.8rem;">	
	<a href="'.$imgmodel12.'">'.$model12.'</a>
	<a href="'.$imgmodel13.'">'.$model13.'</a>
	<a href="'.$imgmodel14.'">'.$model14.'</a>,
	<a href="'.$imgmodel15.'">'.$model15.'</a>,
	<a href="'.$imgmodel16.'">'.$model16.'</a>,
	<a href="'.$imgmodel17.'">'.$model17.'</a>,
	<a href="'.$imgmodel18.'">'.$model18.'</a>,
	<a href="'.$imgmodel19.'">'.$model19.'</a>,
	<a href="'.$imgmodel20.'">'.$model20.'</a>,
	<a href="'.$imgmodel21.'">'.$model21.'</a>,
</span></p>
';

?>