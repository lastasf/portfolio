<?php
// Файлы phpmailer
require 'class.phpmailer.php';
require 'class.smtp.php';

$name = $_POST['name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$firm = $_POST['firm'];
$city = $_POST['city'];
$message = $_POST['message'];
$subject = $_POST['subject'];

// Настройки
$mail = new PHPMailer;

$mail->isSMTP(); 
$mail->Host = 'smtp.mail.ru';  
$mail->SMTPAuth = true;                      
$mail->Username = 'gtksnab'; // Ваш логин в Яндексе. Именно логин, без @yandex.ru
$mail->Password = 'Sanshez123gtk'; // Ваш пароль
$mail->SMTPSecure = 'ssl';                            
$mail->Port = 465;
$mail->CharSet = "UTF-8"; // кодировка
$mail->setFrom('gtksnab@mail.ru'); // Ваш Email
$mail->addAddress('gtksnab@mail.ru'); // Email получателя


// Прикрепление файлов
  for ($ct = 0; $ct < count($_FILES['userfile']['tmp_name']); $ct++) {
        $uploadfile = tempnam(sys_get_temp_dir(), sha1($_FILES['userfile']['name'][$ct]));
        $filename = $_FILES['userfile']['name'][$ct];
        if (move_uploaded_file($_FILES['userfile']['tmp_name'][$ct], $uploadfile)) {
            $mail->addAttachment($uploadfile, $filename);
        } else {
            $msg .= 'Failed to move file to ' . $uploadfile;
        }
    }   
                                 
// Письмо
$mail->isHTML(true); 
$mail->Subject = "$subject"; // Заголовок письма
$mail->Body    = "Отправлено с сайта www.elco-test-6.ru<br>Имя: $name<br> Почта: $email<br> Телефон: $phone<br> Компания: $firm<br> Город: $city<br> Сообщение:<br>$message "; // Текст письма

// Результат
if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'ok';
}
?>