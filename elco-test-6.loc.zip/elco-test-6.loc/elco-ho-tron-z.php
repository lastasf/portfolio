<?php    
    require "var/var.php";
    require "title.php";
    $title = "$modelFirst2Title";
    $description = "$modelFirst2Description";
    $headerClass = "header-other-pages";
    $mainPage = "/";
    require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li> двухступенчатые</li>
                    </ul>
                </div>
            </div>
        </div>
     
        <!--Second-level-2-->
        <div class="second-level-2">
            <div class="mt-4">
                <h1 class="text-center">Двухступенчатые моноблочные горелки ELCO HO-TRON</h1>
                <div class="line-style" style="margin: 0 auto;"></div>
            </div>

            <a href="<?=$imgmodel4?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel4?>.jpg" alt="<?=$model4?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model4?></h2>
                    <p>Мощность горелки мин (кВт)   205,
                    Мощность горелки макс (кВт)     410,
                    Электродвигатель (кВт)  0,74,
                    Класс защиты    IP40</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel5?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model5?></h2>
                    <p>Мощность горелки мин (кВт)   205,
                    Мощность горелки макс (кВт)     570,
                    Электродвигатель (кВт)  1,1,
                    Класс защиты    IP40</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel5?>.jpg" alt="<?=$model5?>" class="img-fluid">
                </div> 
            </div></a>

            <a href="<?=$imgmodel6?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel6?>.jpg" alt="<?=$model6?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model6?></h2>
                    <p>Мощность горелки мин (кВт)   465,
                    Мощность горелки макс (кВт)     930,
                    Электродвигатель (кВт)  1,5,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel7?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model7?></h2>
                    <p>Мощность горелки мин (кВт)   682,
                    Мощность горелки макс (кВт)     1395,
                    Электродвигатель (кВт)  2,2,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel7?>.jpg" alt="<?=$model7?>" class="img-fluid">
                </div> 
            </div></a>

            <a href="<?=$imgmodel8?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel8?>.jpg" alt="<?=$model8?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model8?></h2>
                    <p>Мощность горелки мин (кВт)   682,
                    Мощность горелки макс (кВт)     1700,
                    Электродвигатель (кВт)  3,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel9?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model9?></h2>
                    <p>Мощность горелки мин (кВт)   682,
                    Мощность горелки макс (кВт)     2093,
                    Электродвигатель (кВт)  4,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel9?>.jpg" alt="<?=$model9?>" class="img-fluid">
                </div> 
            </div></a>

            <a href="<?=$imgmodel10?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel10?>.jpg" alt="<?=$model10?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model10?></h2>
                    <p>Мощность горелки мин (кВт)   1000,
                    Мощность горелки макс (кВт)     3000,
                    Электродвигатель (кВт)  7,5,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel11?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model11?></h2>
                    <p>Мощность горелки мин (кВт)   1300,
                    Мощность горелки макс (кВт)     3900,
                    Электродвигатель (кВт)  9,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel11?>.jpg" alt="<?=$model11?>" class="img-fluid">
                </div> 
            </div></a>
            
        </div>        
        <!--End of second-level-2-->  

       
    </div>
</section>

<div class="py-30"></div>

<?php
    require "footer.php";
?>	