<?php    
    require "var/var.php";
    require "title.php";
    $title = "$modelFirst1Title";
    $description = "$modelFirst1Description";
    $headerClass = "header-other-pages";
    $mainPage = "/";
    require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li> одноступенчатые</li>
                    </ul>
                </div>
            </div>
        </div>
       

     
        <!--Second-level-2-->
        <div class="second-level-2">
            <div class="mt-4">
                <h1 class="text-center">Одноступенчатые моноблочные горелки ELCO HO-TRON</h1>
                <div class="line-style" style="margin: 0 auto;"></div>
            </div>

            <a href="<?=$imgmodel1?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel1?>.jpg" alt="<?=$model1?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model1?></h2>
                    <p>Мощность горелки мин (кВт)   68,
                    Мощность горелки макс (кВт)     136,
                    Электродвигатель (кВт)  0,45,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel2?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model2?></h2>
                    <p>Мощность горелки мин (кВт)   108,
                    Мощность горелки макс (кВт)     227,
                    Электродвигатель (кВт)  0,45,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel2?>.jpg" alt="<?=$model2?>" class="img-fluid">
                </div> 
            </div></a>

            <a href="<?=$imgmodel3?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel3?>.jpg" alt="<?=$model3?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model3?></h2>
                    <p>Мощность горелки мин (кВт)   170,
                    Мощность горелки макс (кВт)     340,
                    Электродвигатель (кВт)  0,74,
                    Класс защиты    IP40</p>
                </div>
            </div></a>
            
        </div>        
        <!--End of second-level-2-->  

       
    </div>
</section>

<div class="py-30"></div>

<?php
    require "footer.php";
?>	