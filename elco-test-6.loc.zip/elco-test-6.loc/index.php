<?php
require "title.php";
$title = "$indexTitle";
$description = "$indexDescription";
$headerClass = "";
$mainPage = "";
require "header.php";
?>


<!-- Slider -->
<div class="mySlides-768">
    <div style="background-image:url(img/elco-bg.jpg); transition: background-image 3s ease; opacity: 0.9;"
         class="mySlides slider-content">
        <div class="container">
            <h1 class="text-uppercase pl-3 pb-2" style="max-width: 45%; background: #fff; border-left: 3px solid #BD3826; border-bottom: 3px solid #BD3826; box-shadow: -10px 10px 20px #000;"><span>Моноблочные горелки</span><br>ELCO HO-TRON <br></h1>
            <a data-toggle="modal" data-target="#myModal" href="#" class="btn px-4">ЗАКАЗАТЬ ГОРЕЛКУ</a>
        </div>
    </div>
</div>

<div style="background:white;" class="text-center mySlides-767 slider-content">
    <h1 class="text-uppercase"><span>Моноблочные горелки</span><br>ELCO HO-TRON<br></h1>
    <a data-toggle="modal" data-target="#myModal" href="#" class="btn">ЗАКАЗАТЬ ГОРЕЛКУ</a>
</div>
<!-- End of Slider -->

<!-- Catalogue -->
<section id="catalogue" class="pt-60 pb-90">
    <div class="article-list">
        <div class="container">
            <div class="intro">
                <h2 class="text-center mt-5">Каталог моноблочных горелкок ELCO HO-TRON</h2>
                <div class="line-style" style="margin: 0 auto 50px;"></div>
            </div>
            <div class="row articles mt-4">
                <div class="col-12 col-md-4 col-lg-4 catalogue-a p-3"><a href="elco-ho-tron" style="color: black;">
                   <div style="width: 80%; padding-bottom: 80%; margin: 10px auto 20px; background: url(img/elco-ho-tron-0-135.jpg); background-size: 100% auto; border-radius: 50%;"></div>
                    <h4 class="name text-center">Моноблочные горелки ELCO HO-TRON<br>одноступенчатые</h4></a>
                </div>
                <div class="col-12 col-md-4 col-lg-4 catalogue-a p-3"><a href="elco-ho-tron-z" style="color: black;">
                    <div style="width: 80%; padding-bottom: 80%; margin: 10px auto 20px; background: url(img/elco-ho-tron-3-1700-z.jpg); background-size: 100% auto; border-radius: 50%;"></div>
                    <h4 class="name text-center">Моноблочные горелки ELCO HO-TRON<br>двухступенчатые</h4></a>
                </div>
                <div class="col-12 col-md-4 col-lg-4 catalogue-a p-3"><a href="elco-ho-tron-r" style="color: black;">
                    <div style="width: 80%; padding-bottom: 80%; margin: 10px auto 20px; background: url(img/elco-ho-tron-7-15000-r.jpg); background-size: 100% auto; border-radius: 50%;"></div>
                    <h4 class="name text-center">Моноблочные горелки ELCO HO-TRON<br>плавно-двухступенчатые</h4></a>
                </div>
            </div>
        </div>
    </div>
    <div class="py-30"></div>
</section>
<!-- End of Catalogue -->

<!-- Product Sec -->
<section id="product" class="py-90" style="background: #eee;">
    <div class="container">
        <div class="intro">
            <h2 class="text-center">О моноблочных горелках ELCO HO-TRON</h2>
            <div class="line-style" style="margin: 0 auto; background: #000;"></div>
        </div>
        <div class="my-5 text-center">            
            <p class="text-left">На нашем сайте вы найдете полный ассортимент горелок ELCO типоряда HO-TRON.<br>Горелки одноступенчатые: HO-TRON 0.135, HO-TRON 0.225, HO-TRON 1.350. Горелки двухступенчатые: HO-TRON 1.350 Z, HO-TRON 2.580 Z, HO-TRON 2.930 Z, HO-TRON 2.1400 Z, HO-TRON 3.1700 Z, HO-TRON 3.2100 Z, HO-TRON 4.3000 Z, HO-TRON 4.3900 Z3. Горелки плавно-двухступенчатые с механическим регулированием мощности: HO-TRON 4.3000 R, HO-TRON 4.3900 R, HO-TRON 5.5000 R, HO-TRON 5.5800 R, HO-TRON 6.7200 R, HO-TRON 6.8500 R, HO-TRON 6.10500 R, HO-TRON 6.13000 R, HO-TRON 7.15000 R, HO-TRON 7.17000 R.<br>Заказать горелки ELCO HO-TRON  со скидкой можно на нашем сайте, через удобную форму обратной связи или связавшись с нами по телефону 8 (495) 131-57-49.</p>
        </div>
        <div class="row">
            <div class="col-md-4 text-center">
                <p class="product-svg"><img src="img/svg/1.svg" alt="svg"></p>
                <h5 class="mb-20">Качество</h5>
                <p>Горелки ELCO HO-TRON отвечают всем современным стандартам безопасности</p>
            </div>
            <div class="col-md-4 text-center">
                <p class="product-svg"><img src="img/svg/3.svg" alt="svg"></p>
                <h5 class="mb-20">Гарантия</h5>
                <p>Покупая горелки ELCO HO-TRON на нашем сайте вы получаете фирменную гарантию производителя</p>
            </div>
            <div class="col-md-4 text-center">
                <p class="product-svg"><img src="img/svg/2.svg" alt="svg"></p>
                <h5 class="mb-20">Ассортимент запчастей</h5>
                <p>Мы осуществляем доставку необходимого оборудования по всем регионам России</p>
            </div>
        </div>

        <div class="row justify-content-center my-5">
            <div class="col-10 col-lg-5">
                <div style="padding-bottom: 100%; background: url(img/elco-ho-tron-3-1700-z.jpg); background-size: 100% auto; border-radius: 50%;"></div>
            </div>            
        </div>

        <div class="row">
            <div class="col-md-4 text-center">
                <p class="product-svg"><img src="img/svg/4.svg" alt="svg"></p>
                <h5 class="mb-20">Доставка по РФ</h5>
                <p>Наша компания доставляет запчасти и комплектующие в Москве и по всей России!</p>
            </div>
            <div class="col-md-4 text-center">
                <p class="product-svg"><img src="img/svg/5.svg" alt="svg"></p>
                <h5 class="mb-20">Все запчасти</h5>
                <p>На сайте представлен полный ассортимент запчастей и комплектующих ELCO.</p>
            </div>
            <div class="col-md-4 text-center">
                <p class="product-svg"><img src="img/svg/6.svg" alt="svg"></p>
                <h5 class="mb-20">Качество</h5>
                <p>Фирменное качество ELCO обеспечивает надежность работы всех комплектующих.</p>
            </div>
        </div>        

    </div>
   
</section>
<!-- /Tech Sec -->

<!-- Contacts -->
<section id="contacts" class="pt-90">
    <div class="container">
        <h2 class="print-none">Контакты</h2>
        <div class="line-style print-none"></div>
        <div class="print-none">Мы занимаемся поставками горелкок для частных и промышленного водоснабжения с 2011 года и являемся официальным дилером компании ELCO на территории РФ. Выбрав нашу компанию, Вы всегда можете быть уверены в доставке оригинальных горелкок для вашего бизнеса.</div>        
        <div class="print-ok">
            <p>Наш офис расположен по адресу:</p>
            <p>г. Москва, станция метро Сходненская, улица Новопоселковая 6 к217.</p>
            <p>Для того чтобы к нам добраться садитесь в первый вагон от центра. Из стеклянных дверей выходите направо и идете прямо до конца перехода, затем поворачиваете налево и поднимаетесь по ступенькам. Рядом с вами будет располагаться KFC, недалеко от которого, вы увидите трамвайную остановку.</p>
            <p>Вам нужен трамвай №6. Остановка называется «Новопоселковая улица». Через дорогу от вас будет большое серое здание. Пройдите вдоль здания 150м до первого подъезда мы встретим Вас на посту охраны.</p>
        </div>
        <div class="row mt-5">
            <div class="contact-info col-lg-4 print-none" style="background: #eee;">
                <h5 class="my-3">Наши контакты:</h5>
                <div>
                    <ul class="list-unstyled">
                        <li>
                            <i class="fa fa-building"></i>
                            <a>ООО "ГТК"</a>
                        </li>
                        <li>
                            <i class="fa fa-phone"></i>
                            <a href="tel:+74957619471">+7 (495) 131-57-49</a>
                        </li>
                        <li>
                            <i class="fa fa-envelope-o"></i>
                            <a href="mailto:gtksnab@mail.ru">gtksnab@mail.ru</a>
                        </li>
                        <li>
                            <i class="fa fa-map-marker"> </i>
                            <span> г. Москва, Южное Тушино, улица Новопоселковая, д. 6, кор. 217</span>
                        </li>
                        <li>
                            <i class="fa fa-calendar"></i>
                            <span>Пн-Чт: 09:00 - 18:00, Пт: 09:00 - 17:00</span>
                        </li>
                        <li>
                            <i class="fa fa-users"></i>
                            <span>Мы в социальных сетях:</span><br>
                            <a style="margin-left: 32px;" href="https://www.facebook.com/gtksnab" target="_blank"><i class="fa fa-facebook-square fa-lg facebook-style"></i></a>
                            <a href="https://vk.com/public178350400" target="_blank"><i class="fa fa-vk fa-lg vk-style"></i></a>
                            <a href="https://www.instagram.com/gtk.co/" target="_blank"><i class="fa fa-instagram fa-lg instagram-style"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-8">
                <iframe src="https://www.google.com/maps/embed?pb=!1m28!1m12!1m3!1d10655.677242489264!2d37.43131131113169!3d55.843922887087814!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m13!3e0!4m5!1s0x46b547f4809604d1%3A0x892e4ddefa1402dc!2z0YHRgi4g0LwuINCh0YXQvtC00L3QtdC90YHQutCw0Y8sINCc0L7RgdC60LLQsA!3m2!1d55.851878799999994!2d37.4387715!4m5!1s0x46b547e42d055555%3A0x25508948c36427dd!2z0J3QvtCy0L7Qv9C-0YHQtdC70LrQvtCy0LDRjyDRg9C7LiwgNiwg0JzQvtGB0LrQstCwLCDQoNC-0YHRgdC40Y8sIDEyMzQyMw!3m2!1d55.837773899999995!2d37.442379599999995!5e0!3m2!1sru!2sru!4v1547561956132"
                        frameborder="0" style="border:0" allowfullscreen>
                </iframe>
            </div>
        </div>
        <div class="contacts-btn mt-2"><a class="btn print-none" onclick="window.print();">Распечатать схему проезда</a></div>
    </div>
</section>
<!-- End of Contacts -->

<!-- Form -->
<section id="form-section" class="py-45 form-section">
    <div class="container">
        <h5>ОТПРАВИТЬ ЗАЯВКУ</h5>
        <form enctype="multipart/form-data" method="post" id="form">
            <p class="contact-form-margin-style-p" style="color:red;">* Поля обязательные для заполнения</p>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-field">
                        <input type="text" name="name" class="theme-input-style" placeholder="Контактное лицо *"
                               required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-field">
                        <input type="email" name="email" class="theme-input-style" placeholder="E-mail *" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-field">
                        <input type="text" name="phone" class="theme-input-style" placeholder="Телефон *" required
                               data-parsley-pattern="^[\d\+\-\.\(\)\/\s]*$">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-field">
                        <input type="text" name="firm" class="theme-input-style" placeholder="Компания">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-field">
                        <input type="text" name="city" class="theme-input-style" placeholder="Город">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-field">
                        <select name="subject" class="theme-input-style" style="-webkit-appearance: none; color: #777;">
                            <option value="" style="display:none;">Выбрать тему письма &#9660;</option>
                            <option value="Заявка">Заявка</option>
                            <option value="Звонок">Звонок</option>
                            <option value="Консультации">Консультации</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-field">
                <textarea name="message" class="theme-input-style" placeholder="Текст письма *" required></textarea>
            </div>
            <div class="row">
                <div class="col-md-8">
                    <div class="form-field">
                        <input type="file" name="userfile[]" multiple id="userfile1" class="w100"
                               accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.ppt,.pptx,.odt,.avi,.ogg,.m4a,.mov,.mp3,.mp4,.mpg,.wav,.wmv">
                    </div>
                </div>               
                <div class="col-md-4" style="text-align:right;">                    
                    <button type="submit" class="btn px-5 submit-form-10 btn-product"
                            onclick="ym(54314487, 'reachGoal', 'order'); return true;">ОТПРАВИТЬ
                    </button>
                </div>
            </div>
            <div id="formResponse" class="form-response p-2 mb-3 text-center" style="display:none;">Сообщение отправлено.</div>
            <div class="form-field">
                <label><input type="checkbox" name="acceptance-10" class="checkbox-10" value="1" aria-invalid="false"
                              checked=""><span class="contact-form-margin-style-span">«Согласен на обработку персональных данных. Ставя отметку, я даю свое согласие на обработку моих персональных данных в соответствии с законом №152-ФЗ «О персональных данных» от 27.07.2006 и принимаю условия <a
                                class="refer" href="/politika" target="_blank">Политики конфиденциальности персональных данных</a>».</span></label>
            </div>

        </form>
    </div>
</section>
<!-- End of Form -->

<?php
require "footer.php";
?>
	