<?php    
    require "var/var.php";
    require "title.php";
    $title = "$modelFirst3Title";
    $description = "$modelFirst3Description";
    $headerClass = "header-other-pages";
    $mainPage = "/";
    require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li> плавно-двухступенчатые</li>
                    </ul>
                </div>
            </div>
        </div>
     
        <!--Second-level-2-->
        <div class="second-level-2">
            <div class="mt-4">
                <h1 class="text-center">Плавно-двухступенчатые моноблочные горелки ELCO HO-TRON</h1>
                <div class="line-style" style="margin: 0 auto;"></div>
            </div>

            <a href="<?=$imgmodel12?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel12?>.jpg" alt="<?=$model12?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model12?></h2>
                    <p>Мощность горелки мин (кВт)   1000,
                    Мощность горелки макс (кВт)     3000,
                    Электродвигатель (кВт)  7,5,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel13?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model13?></h2>
                    <p>Мощность горелки мин (кВт)   1300,
                    Мощность горелки макс (кВт)     3900,
                    Электродвигатель (кВт)  9,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel13?>.jpg" alt="<?=$model13?>" class="img-fluid">
                </div> 
            </div></a>

            <a href="<?=$imgmodel14?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel14?>.jpg" alt="<?=$model14?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model14?></h2>
                    <p>Мощность горелки мин (кВт)   1578,
                    Мощность горелки макс (кВт)     5000,
                    Электродвигатель (кВт)  11,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel15?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model15?></h2>
                    <p>Мощность горелки мин (кВт)   1795,
                    Мощность горелки макс (кВт)     5800,
                    Электродвигатель (кВт)  15,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel15?>.jpg" alt="<?=$model15?>" class="img-fluid">
                </div> 
            </div></a>

            <a href="<?=$imgmodel16?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel16?>.jpg" alt="<?=$model16?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model16?></h2>
                    <p>Мощность горелки мин (кВт)   2417,
                    Мощность горелки макс (кВт)     7500,
                    Электродвигатель (кВт)  15,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel17?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model17?></h2>
                    <p>Мощность горелки мин (кВт)   2750,
                    Мощность горелки макс (кВт)     8500,
                    Электродвигатель (кВт)  18,5,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel17?>.jpg" alt="<?=$model17?>" class="img-fluid">
                </div> 
            </div></a>

            <a href="<?=$imgmodel18?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel18?>.jpg" alt="<?=$model18?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model18?></h2>
                    <p>Мощность горелки мин (кВт)   3300,
                    Мощность горелки макс (кВт)     10500,
                    Электродвигатель (кВт)  22,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel19?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model19?></h2>
                    <p>Мощность горелки мин (кВт)   4367,
                    Мощность горелки макс (кВт)     12500,
                    Электродвигатель (кВт)  37,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel19?>.jpg" alt="<?=$model19?>" class="img-fluid">
                </div> 
            </div></a>

            <a href="<?=$imgmodel20?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">
                <div class="col-md-2">
                    <img src="img/products/<?=$imgmodel20?>.jpg" alt="<?=$model20?>" class="img-fluid">
                </div> 
                <div class="col-md-10 px-md-5">
                    <h2><?=$h1Model?> <?=$model20?></h2>
                    <p>Мощность горелки мин (кВт)   5000,
                    Мощность горелки макс (кВт)     15000,
                    Электродвигатель (кВт)  45,
                    Класс защиты    IP42</p>
                </div>
            </div></a>

            <a href="<?=$imgmodel21?>"><div class="row second-level-2-card mt-5 mb-4 p-3 mx-1">               
                <div class="col-md-10 px-md-5 order-2">
                    <h2><?=$h1Model?> <?=$model21?></h2>
                    <p>Мощность горелки мин (кВт)   5700,
                    Мощность горелки макс (кВт)     17000,
                    Электродвигатель (кВт)  55,
                    Класс защиты    IP42</p>
                </div>
                <div class="col-md-2 order-1 order-md-3">
                    <img src="img/products/<?=$imgmodel21?>.jpg" alt="<?=$model21?>" class="img-fluid">
                </div> 
            </div></a>
          
        </div>        
        <!--End of second-level-2-->  

       
    </div>
</section>

<div class="py-30"></div>

<?php
    require "footer.php";
?>	