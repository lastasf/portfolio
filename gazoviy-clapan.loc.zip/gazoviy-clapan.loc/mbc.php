<?php
require "title.php";
$title = "$model9Title";
$description = "$model9Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/mbc">Газовые мультиблоки Dungs MBC...</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Газовые мультиблоки Dungs MBC-SE</span>
            <span class="h1-product-span" style="display:none;">Газовые клапаны Dungs MBC-DLE</span>
            <span class="h1-product-span" style="display:none;">Газовые клапаны Dungs MBC-VEF</span>
        </h1>
        <div class="line-style"></div>
        <div class="row">
            <div class="col-lg-4 my-5">
                <div class="slides-product-container">
                    <div class="slides-product text-center mb-3">
                        <img class="img-fluid" src="img/products/mbc-9-1.png" alt="Газовые клапаны Dungs MBC-SE">
                    </div>
                    <div class="slides-product text-center mb-3" style="display:none;">
                        <img class="img-fluid" src="img/products/mbc-9-2.png" alt="клапаны Dungs MBC-DLE">
                    </div>
                    <div class="slides-product text-center mb-3" style="display:none;">
                        <img class="img-fluid" src="img/products/mbc-9-3.png" alt="Газовые клапаны Dungs MBC-VEF">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mbc-9-1.png" alt="Газовые клапаны Dungs MBC-SE">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mbc-9-2.png" alt="клапаны Dungs MBC-DLE">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mbc-9-3.png" alt="Газовые клапаны Dungs MBC-VEF">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 my-3 px-lg-5">
                <div class="product-description">
                    <h3>Описание Dungs MBC-SE</h3>
                    <p>Dungs MBC SE - это новое поколение мультиблоков Dungs. Благодаря эргономичной конструкции стало
                        возможно разместить газовую линию на одном корпусе, тем самым, обеспечивая максимально
                        эффективную пропускную способность. Благодаря точной регулировке происходит плавная регулировка
                        выходного давления. Максимальное рабочее давление составляет 360 мбар.</p>
                    <p>Dungs MBC-SE: <span class="font-weight-bold" style="font-size:0.8rem;">MBC-300-SE S22, MBC-300-SE S82, MBC-300-SE S302, MBC-700-SE S22, MBC-700-SE S82, MBC-700-SE S302, MBC-1200-SE S22, MBC-1200-SE S82, MBC-1200-SE S302, MBC-1900-SE-65, MBC-3100-SE-80, MBC-5000-SE-100.</span>
                    </p>
                </div>
                <div class="product-description" style="display:none;">
                    <h3>Описание Dungs MBC-DLE</h3>
                    <p>Dungs MBC DLE - это новое поколение мультиблоков сочетающее быстро и медленно открывающиеся
                        клапаны, дроссель расхода газа. Максимальное рабочее давление составляет от 65 до 120 мбар.
                        Мультиблок присоединяется при помощи фланцев Rp 3/8 - Rp 3/4. Для защиты от грязи и пыли
                        используется фильтр тонкой очистки.</p>
                    <p>Dungs MBC-DLE: <span class="font-weight-bold" style="font-size:0.8rem;">MBC-65-DLE-S20, MBC-65-DLE-S40, MBC-120-DLE-S20, MBC-120-DLE-S40.</span>
                    </p>
                </div>
                <div class="product-description" style="display:none;">
                    <h3>Описание Dungs MBC-VEF</h3>
                    <p>Dungs MBC VEF эффективный мультиблок с высокочувствительной настройкой соотношения газа и
                        воздуха. Масимальное рабочее давление составляет 360 мбар. Устройство присоединяется при помощи
                        фланцев Rp 1/2 - Rp 2. Фланцевое соединение DN 65 - DN 100. Для защиты от грязи и пыли
                        используется фильтр тонкой очистки.</p>
                    <p>Dungs MBC-VEF: <span class="font-weight-bold" style="font-size:0.8rem;">MBC-300-VEF, MBC-700-VEF, MBC-1200-VEF, MBC-1900-VEF-65, MBC-3100-VEF-80, MBC-5000-VEF-100.</span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="tabs-for-products">
            <div class="row">
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark" style="border-bottom: none;"><h5>
                        MBC-SE</h5></div>
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark"
                     style="border-bottom: none; background:black; color:white;"><h5>MBC-DLE</h5></div>
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark tabs-for-products-bookmark-right"
                     style="border-bottom: none; background:black; color:white;"><h5>MBC-VEF</h5></div>
            </div>


            <!--Первое поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-300-SE S22</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 30 м3/час</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 3/4</li>
                                <li>Входное давление: 15-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-300-SE S82</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 30 м3/час</li>
                                <li>Диапазон регулирования: 5-80 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                                <li>Входное давление: 15-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-300-SE S302</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 30 м3/час</li>
                                <li>Диапазон регулирования: 30-300 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                                <li>Входное давление: 35-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-700-SE S22</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 70 м3/час</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 1/4′</li>
                                <li>Входное давление: 15-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-700-SE S82</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 70 м3/час</li>
                                <li>Диапазон регулирования: 5-80 мбар</li>
                                <li>Соединение: Rp 1 1/4′</li>
                                <li>Входное давление: 15-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-700-SE S302</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 70 м3/час</li>
                                <li>Диапазон регулирования: 30-300 мбар</li>
                                <li>Соединение: Rp 1 1/4′</li>
                                <li>Входное давление: 35-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-1200-SE S22</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 120 м3/час</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 2′</li>
                                <li>Входное давление: 15-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-1200-SE S82</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 120 м3/час</li>
                                <li>Диапазон регулирования: 5-80 мбар</li>
                                <li>Соединение: Rp 2′</li>
                                <li>Входное давление: 15-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-1200-SE S302</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 120 м3/час</li>
                                <li>Диапазон регулирования: 30-300 мбар</li>
                                <li>Соединение: Rp 2′</li>
                                <li>Входное давление: 35-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-1900-SE-65</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 190 м3/час</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: DN 65</li>
                                <li>Входное давление: до 360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-3100-SE-80</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 310 м3/час</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: DN 80</li>
                                <li>Входное давление: до 360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-se.png" class="img-fluid" alt="Dungs mbc-se">
                            <h4>MBC-5000-SE-100</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 500 м3/час</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: DN 100</li>
                                <li>Входное давление: до 360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец первого поля карточки-->


            <!--Второе поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-dle.png" class="img-fluid" alt="Dungs mbc-dle">
                            <h4>MBC-65-DLE-S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Диапазон регулирования: 5-150 мбар</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-dle.png" class="img-fluid" alt="Dungs mbc-dle">
                            <h4>MBC-65-DLE-S40</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Диапазон регулирования: 5-150 мбар</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-dle.png" class="img-fluid" alt="Dungs mbc-dle">
                            <h4>MBC-120-DLE-S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 5-150 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-dle.png" class="img-fluid" alt="Dungs mbc-dle">
                            <h4>MBC-120-DLE-S40</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 5-150 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--Конец второго поля карточки-->


            <!--Третье поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-vef.png" class="img-fluid" alt="Dungs mbc-vef">
                            <h4>MBC-300-VEF</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 30 м3/час</li>
                                <li>Соединение: Rp 3/4′</li>
                                <li>Входное давление: до 360 мбар</li>                                
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-vef.png" class="img-fluid" alt="Dungs mbc-vef">
                            <h4>MBC-700-VEF</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 70 м3/час</li>
                                <li>Соединение: Rp 1 1/4′</li>
                                <li>Входное давление: до 360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-vef.png" class="img-fluid" alt="Dungs mbc-vef">
                            <h4>MBC-1200-VEF</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 120 м3/час</li>
                                <li>Соединение: Rp 2′</li>
                                <li>Входное давление: до 360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-vef.png" class="img-fluid" alt="Dungs mbc-vef">
                            <h4>MBC-1900-VEF-65</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 190 м3/час</li>
                                <li>Соединение: DN 65</li>
                                <li>Входное давление: до 360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-vef.png" class="img-fluid" alt="Dungs mbc-vef">
                            <h4>MBC-3100-VEF-80</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 310 м3/час</li>
                                <li>Соединение: DN 80</li>
                                <li>Входное давление: до 360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mbc-vef.png" class="img-fluid" alt="Dungs mbc-vef">
                            <h4>MBC-5000-VEF-100</h4>
                            <ul>
                                <li>Расход газа при перепаде Др=10: 500 м3/час</li>
                                <li>Соединение: DN 100</li>
                                <li>Входное давление: до 360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--Конец третьего поля карточки-->

        </div>
    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	