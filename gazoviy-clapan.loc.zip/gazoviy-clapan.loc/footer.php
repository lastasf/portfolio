	<!-- Back to top -->
	<div class="back-to-top" style="display:none;">
        <a href="#backToTop"><i class="fa fa-chevron-up"></i></a>
    </div>
	<!-- End of Back to top -->
	
	<!-- Footer -->
    <footer class="pt-4">
    	<div class="container">
	        <div class="row mt-4">            	
	            <div class="col-lg-6 pb-3" style="font-size:13px;">ВСЕ ПРАВА ЗАЩИЩЕНЫ 2019.</div>
	            <div class="col-lg-6" style="font-size:13px;">Работая с этим сайтом, Вы даете свое согласие на использование файлов cookie. Это необходимо для нормального функционирования сайта и анализа трафика. <a href="/politika">Подробнее</a></div>              
	        </div>
        </div>
    </footer>
    <!-- End of Footer -->
	
	<!-- Модальное окно -->  
	<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
	  <div class="modal-dialog" role="document">
		<div class="modal-content">	
			<div class="modal-body parsley-validate-wrap">			
				<div class="mb-30 form-section">
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
					<div class="container">
						<h5>ОТПРАВИТЬ ЗАЯВКУ</h5>
						<form enctype="multipart/form-data" method="post" id="form2">				
							<p class="contact-form-margin-style-p" style="color:red;">* Поля обязательные для заполнения</p>
							<div id="formResponse2" class="form-response p-2 mb-3 text-center" style="display:none;">Сообщение отправлено.</div>
							<div class="row">
								<div class="col-md-6">
								<div class="form-field">
									<input type="text" name="name" class="theme-input-style" placeholder="Контактное лицо *" required>
								</div>
								</div>
								<div class="col-md-6">
									<div class="form-field">
										<input type="email" name="email" class="theme-input-style" placeholder="E-mail *" required>
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-field">
										<input type="text" name="phone" class="theme-input-style" placeholder="Телефон *" required data-parsley-pattern="^[\d\+\-\.\(\)\/\s]*$">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-field">
										<input type="text" name="firm" class="theme-input-style" placeholder="Компания">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-field">
										<input type="text" name="city" class="theme-input-style" placeholder="Город">
									</div>
								</div>
								<div class="col-md-6">
									<div class="form-field">
										<select name="subject" class="theme-input-style" style="-webkit-appearance: none; color: #777;"><option value="" style="display:none;">Выбрать тему письма &#9660;</option><option value="Заявка">Заявка</option><option value="Звонок">Звонок</option><option value="Консультации">Консультации</option></select>
									</div>
								</div>
							</div>
							<div class="form-field">
								<textarea id="textarea-footer" name="message" class="theme-input-style" placeholder="Текст письма *" required></textarea>
							</div>
							<div class="form-field">
								<input type="file" name="userfile[]" multiple id="userfile" class="w100" accept=".jpg,.jpeg,.png,.gif,.pdf,.doc,.docx,.ppt,.pptx,.odt,.avi,.ogg,.m4a,.mov,.mp3,.mp4,.mpg,.wav,.wmv" >
							</div>
							<div class="form-field">
								<label><input type="checkbox" name="acceptance-10" class="checkbox-10" value="1" aria-invalid="false" checked=""><span class="contact-form-margin-style-span" style="font-size:12px;"> «Согласен на обработку персональных данных. Ставя отметку, я даю свое согласие на обработку моих персональных данных в соответствии с законом №152-ФЗ «О персональных данных» от 27.07.2006 и принимаю условия <a class="refer" href="/politika" target="_blank">Политики конфиденциальности персональных данных</a>».</span></label>
							</div>				
							<button type="submit" class="btn submit-form-10" onclick="ym(53350531, 'reachGoal', 'order'); return true;">ОТПРАВИТЬ</button>
						</form>
					</div>
				</div>		 
			</div>
		</div>
	  </div>
	</div>
	<!-- Модальное окно конец-->
	
	
	<!--Scripts-->
	
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
	<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>
	<script>
		setTimeout("x()",10);
		function x(){			
			document.getElementsByClassName('loader')[0].style.display = "none";
		}
	</script>
	<script>	
		$(function(){
		  'use strict';
		$('#form').on('submit', function(e){
			e.preventDefault();
			var fd = new FormData( this );
			$.ajax({
			  url: 'formPHP/send.php',
			  type: 'POST',
			  contentType: false, 
			  processData: false, 
			  data: fd,
			  success: function(msg){
		if(msg == 'ok') {
		  $(".button").val("Отправлено");
		  formResponse.style.display = "block";		  
		} else {
				$(".button").val("Ошибка");
				setTimeout(function() {$(".button").val("Отправить");}, 3000);
		}
			  }
			});
		  });
		});
	</script>
	<script>
		$(function(){
		  'use strict';
		$('#form2').on('submit', function(e){
			e.preventDefault();
			var fd = new FormData( this );
			$.ajax({
			  url: 'formPHP/send.php',
			  type: 'POST',
			  contentType: false, 
			  processData: false, 
			  data: fd,
			  success: function(msg){
		if(msg == 'ok') {
		  $(".button").val("Отправлено");
		  formResponse2.style.display = "block";		  
		} else {
				$(".button").val("Ошибка");
				setTimeout(function() {$(".button").val("Отправить");}, 3000);
		}
			  }
			});
		  });
		});
	</script>	
	<script src="js/scripts.js"></script>
	<!--Scripts-->
	
	</body>
</html>