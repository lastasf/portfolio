/*Top nav*/
	trigram.onclick = function (){
		var xNav = document.getElementsByClassName("nav")[0];

		if (xNav.className == "nav nav-close"){ 				
			xNav.className = "nav nav-open";							
		}
		else xNav.className = "nav nav-close";			
	}		
/* End of Top nav*/

if(document.getElementsByClassName("mySlides-768")[0]){ //Проверяем наличие нужного класса на странице
	
	var slideIndex = 1;

	setInterval("showSlides(slideIndex += 1)", 3000); //Включаем таймер,который вызовет функцию slideInterval()

	function showSlides(x){			
		var slides = document.getElementsByClassName("mySlides-768");
		if (x > slides.length){
			slideIndex = 1
		}
		for (var i = 0; i < slides.length; i++) {
			slides[i].style.display = "none";
		}
		slides[slideIndex-1].style.display = "block";  			
	}
	
}

/* Скипты необходимые для меню при прокрутке экрана */	
var bottomHeader = document.getElementsByClassName('bottom-header')[0];
var telAndMail = document.getElementsByClassName('tel-and-mail')[0];
var backToTop = document.getElementsByClassName('back-to-top')[0];

var scrolledHeaderMemuAuto = 0;	
scrolledHeaderMemuAuto = window.pageYOffset || document.documentElement.scrollTop;
if(scrolledHeaderMemuAuto>=1){
	bottomHeader.style.cssText = "box-shadow: 0px 0px 5px black; background:rgb(16, 73, 160);; margin-top:0;";
}

window.onscroll = function() {
	var scrolledHeaderMemu = 0;	
	scrolledHeaderMemu = window.pageYOffset || document.documentElement.scrollTop;

	//появление тени при скроле
	if(scrolledHeaderMemu>=1)			
		bottomHeader.style.cssText = "box-shadow: 0px 0px 5px black; background:rgb(16, 73, 160);; margin-top:0;";
	else			
		bottomHeader.style.cssText = "box-shadow: none;";		
		
	//Появление и исчезновение блока телефон и почта при прокрутке 
	if(screen.width>768){ // На экране менее 768 пикселей шириной скрипт действовать не будет, а блок будет показан сразу
		if(scrolledHeaderMemu>=1)			
			telAndMail.style.display = "block";
		else			
			telAndMail.style.display = "none";
	}
	
	//появление значка для прокрутки экрана вверх
	if(scrolledHeaderMemu>=300)			
		 backToTop.style.display = "block";	
	else			
		 backToTop.style.display = "none";	
}


/* Form */
/*Для формы обратной связи - принятие условий обработки персональных данных*/
if(document.getElementsByClassName("checkbox-10")[0]){
	var checkbox10 = document.getElementsByClassName("checkbox-10");
	checkbox10[0].onchange = function () {
		if(!checkbox10[0].checked) document.getElementsByClassName('submit-form-10')[0].setAttribute("disabled", "");
		else document.getElementsByClassName('submit-form-10')[0].removeAttribute("disabled", "");
	}
	if(document.getElementsByClassName("checkbox-10")[1]){
		checkbox10[1].onchange = function (){
			if(!checkbox10[1].checked) document.getElementsByClassName('submit-form-10')[1].setAttribute("disabled", "");
			else document.getElementsByClassName('submit-form-10')[1].removeAttribute("disabled", "");
		}
	}
}
/* End of Form */


/* Плавная прокрутка */
var $page = $('html, body');
$('a[href*="#"]').click(function() {
    $page.animate({
        scrollTop: $($.attr(this, 'href')).offset().top
    }, 800);
    return false;
});


/*Страница товара*/
if(document.getElementsByClassName('slides-product')[0]){	
	
	/*Слайдер*/
	var slidesProduct = document.getElementsByClassName('slides-product');
	var slidesProductMin = document.getElementsByClassName('slides-product-min');
	
	for(var i=0; i<slidesProduct.length; i++){
		slidesProductMin[i].dataset.productNumber = i; // Присваиваем каждому элементу data-product-number равный индексу
		slidesProductMin[i].onclick = slidesProductShow;		
	}	
	
	function slidesProductShow (){		
		for(var i = 0; i<slidesProduct.length; i++){
			slidesProduct[i].style.display = "none";
		}		
		slidesProduct[this.dataset.productNumber].style.display = "block";
	}	

	/*Вкладки*/
	var tabsForProductsBookmark = document.getElementsByClassName('tabs-for-products-bookmark'); // Корешок вкладки
	var tabsForProductsPage = document.getElementsByClassName('tabs-for-products-page'); // Вкладка	
	var productDescription = document.getElementsByClassName('product-description'); // Описание
	var h1ProductSpan = document.getElementsByClassName('h1-product-span');
	
	for(var i=0; i<tabsForProductsBookmark.length; i++){
		tabsForProductsBookmark[i].dataset.pageNumber = i; // Присваиваем каждому элементу data-product-number равный индексу
		tabsForProductsBookmark[i].onclick = slidesProductPageShow;
	}	
	
	function slidesProductPageShow (){
		for(var i = 0; i<tabsForProductsPage.length; i++){
			tabsForProductsPage[i].style.display = "none";
			tabsForProductsBookmark[i].style.cssText = "border-bottom:1px solid black; background:black; color:white";
			productDescription[i].style.display = "none";
			h1ProductSpan[i].style.display = "none";
		}
		tabsForProductsPage[this.dataset.pageNumber].style.display = "block";
		tabsForProductsBookmark[this.dataset.pageNumber].style.cssText = "border-bottom:none; background:white; color:black;";
		productDescription[this.dataset.pageNumber].style.display = "block";
		h1ProductSpan[this.dataset.pageNumber].style.display = "block";
	}	
	
	/*Попадание номера запчасти в textarea модального окна*/
	var forTextareaFooter = document.getElementsByClassName('for-textarea-footer'); // Кнопка в карточке товара	
	var textareaFooter = document.getElementById('textarea-footer'); // Textarea модального окна
	
	for(var i=0; i<forTextareaFooter.length; i++){		
		forTextareaFooter[i].onclick = funcForTextareaFooter;		
	}
	
	function funcForTextareaFooter(){		
		textareaFooter.value = this.previousElementSibling.previousElementSibling.innerHTML; // nextElementSibling - это
	}
}


