<?php
require "title.php";
$title = "$model8Title";
$description = "$model8Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/mb-vef">Газовые мультиблоки Dungs MB-VEF</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Газовые мультиблоки Dungs MB-VEF</span>
        </h1>
        <div class="line-style"></div>
        <div class="row">
            <div class="col-lg-4 my-5">
                <div class="slides-product-container">
                    <div class="slides-product text-center mb-3">
                        <img class="img-fluid" src="img/products/mb-vef-08-01.png" alt="MB-VEF купить">
                    </div>
                    <div class="slides-product text-center mb-3" style="display:none;">
                        <img class="img-fluid" src="img/products/mb-vef-08-02.png" alt="Dungs MB-VEF купить">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mb-vef-08-01.png" alt="Dungs MB-VEF">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mb-vef-08-02.png" alt="Dungs MB-VEF купить">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 my-3 px-lg-5">
                <div class="product-description">
                    <h3>Описание Dungs MB-VEF</h3>
                    <p>Dungs MB-VEF это бесступенчатой газовый мультиблок объединяющий в себе два газовых клапана и
                        фильтр тонкой очистки. Мультиблок обеспечивает плавное регулирование соотношения газа и воздуха
                        для применения на горелках с прогрессивным и модулируемым регулированием мощности с максимальным
                        уровнем точности. Все это обеспечивает высокий уровень работы газовой горелки и высокий уровень
                        безопасности.</p>
                    <p>Dungs MB-VEF:
                        <span class="font-weight-bold" style="font-size:0.8rem;">MB-VEF 407 B01 S10, MB-VEF 407 B01 S12, MB-VEF 407 B01 S30, MB-VEF 407 B01 S32, MB-VEF 412 B01 S10, MB-VEF 412 B01 S12, MB-VEF 412 B01 S30, MB-VEF 412 B01 S32, MB-VEF 415 B01, MB-VEF 415 B01 S12, MB-VEF 415 B01 S30, MB-VEF 415 B01 S32, MB-VEF 420 B01 S10, MB-VEF 420 B01 S12, MB-VEF 420 B01 S30, MB-VEF 420 B01 S32, MB-VEF 425 B01 S10, MB-VEF 425 B01 S12, MB-VEF 425 B01 S30, MB-VEF 425 B01 S32.</span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="tabs-for-products">

            <!--Первое поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 407 B01 S10</h4>
                            <ul>
                               <li>Расход газа при перепаде р=10 мбар: 18 м3/час</li>
                               <li>Соединение: Rp3/4′</li>
                               <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 407 B01 S12</h4>
                            <ul>
                               <li>Макс. раб. давл.: 5-100 мбар</li>
                               <li>Расход газа при перепаде р=10 мбар: 18 м3/час</li>
                               <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 407 B01 S30</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 18 м3/час</li>
                                <li>Соединение: Rp3/4′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 407 B01 S32</h4>
                            <ul>
                                <li>Макс. раб. давл.: 100-360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 18 м3/час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 412 B01 S10</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 38 м3/час</li>
                                <li>Соединение: Rp1 1/4′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 412 B01 S12</h4>
                            <ul>
                                <li>Макс. раб. давл.: 5-100 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 38 м3/час</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 412 B01 S30</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 38 м3/час</li>
                                <li>Соединение: Rp1 1/4′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 412 B01 S32</h4>
                            <ul>
                                <li>Макс. раб. давл.: 100-360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 38 м3/час</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 415 B01</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 58 м3/час</li>
                                <li>Соединение: Rp1 1/2′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 415 B01 S12</h4>
                            <ul>
                                <li>Макс. раб. давл.: 5-100 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 58 м3/час</li>
                                <li>Соединение: Rp 1 1/2′/li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 415 B01 S30</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 58 м3/час</li>
                                <li>Соединение: Rp1 1/2′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 415 B01 S32</h4>
                            <ul>
                                <li>Макс. раб. давл.: 100-360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 58 м3/час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 420 B01 S10</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 72 м3/час</li>
                                <li>Соединение: Rp2′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 420 B01 S12</h4>
                            <ul>
                                <li>Макс. раб. давл.: 5-100 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 75 м3/час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 420 B01 S30</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 72 м3/час</li>
                                <li>Соединение: Rp2′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 420 B01 S32</h4>
                            <ul>
                                <li>Макс. раб. давл.: 100-360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 75 м3/час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 425 B01 S10</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 150 м3/час</li>
                                <li>Соединение: Rp2′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 425 B01 S12</h4>
                            <ul>
                                <li>Макс. раб. давл.: 5-100 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м3/час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 425 B01 S30</h4>
                            <ul>
                                <li>Расход газа при перепаде р=10 мбар: 150 м3/час</li>
                                <li>Соединение: Rp2′</li>
                                <li>Входное давление: 100-360 мбар</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-vef-415-425.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-VEF 425 B01 S32</h4>
                            <ul>
                                <li>Макс. раб. давл.: 100-360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м3/час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>


                </div>
            </div>
            <!--Конец первого поля карточки-->


        </div>
    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	