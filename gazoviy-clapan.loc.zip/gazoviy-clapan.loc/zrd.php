<?php
require "title.php";
$title = "$model4Title";
$description = "$model4Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/zrd">Газовые клапаны Dungs ZRD...</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Газовые клапаны Dungs ZRD</span>
            <span class="h1-product-span" style="display:none;">Газовые клапаны Dungs ZRLE</span>
            <span class="h1-product-span" style="display:none;">Газовые клапаны Dungs ZRDLE</span>
        </h1>
        <div class="line-style"></div>
        <div class="row">
            <div class="col-lg-4 my-5">
                <div class="slides-product-container">
                    <div class="slides-product text-center mb-5">
                        <img class="img-fluid" src="img/products/zrd-4-1.png" alt="Dungs ZRD купить">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="slides-product-min">

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 my-3 px-lg-5">
                <div class="product-description">
                    <h3>Описание Dungs ZRD</h3>
                    <p>Dungs ZRD - это двухступенчатый электромагнитный клапан позволяющий выполнить точную настройку
                        основного расхода газа. Клапан ZRD позволяет выполнить быстрое закрытие при отключение котла или
                        горелки или при аварийной блокировке. Максимальное давление газа составляет 360 мбар.
                        Подключение клапана происходит при помощи штекерного разъема. При установке и монтаже, для
                        защиты от загрязнения необходимо применять специальные фильтры-грязеуловители.</p>
                    <p>Dungs ZRD: <span class="font-weight-bold" style="font-size:0.8rem;">ZRD 407 5, ZRD 410 5, ZRD 415 5, ZRD 420 5.</span>
                    </p>
                </div>
                <div class="product-description" style="display:none;">
                    <h3>Описание Dungs ZRLE</h3>
                    <p>Dungs ZRLE - это двухступенчатый электромагнитный клапан класса А, группы 2. Данная модель имеет
                        быстрое закрытие и медленное открытие с плавной регулировкой изначального расхода газа.
                        Максимальное рабочее давление составляет 360 мбар. Резьбовое присоединение от 3/4'' до 2''.
                        Клапан ZRLE соответствует всем европейским нормам и стандартам IP54 и устанавливается строго
                        исполнительным механизмом вбок или вверх.</p>
                    <p>Dungs ZRLE: <span class="font-weight-bold" style="font-size:0.8rem;">ZRLE 407 5, ZRLE 410 5, ZRLE 415 5, ZRLE 420 5.</span>
                    </p>
                </div>
                <div class="product-description" style="display:none;">
                    <h3>Описание Dungs ZRDLE</h3>
                    <p>Dungs ZRDLE - это двухступенчатый электромагнитный клапан с функцией точной настройки основного
                        расхода газа. Клапан оснащен быстрым и медленным открытием с регулировкой начального расхода
                        топлива при запуске. Клапаны данной серии имеют резьбовое присоединение от 3/4'' до 2'' и с
                        фланцевым присоединением DN40-DN50. Класс защиты соответствует стандартам IP54. Исполнительный
                        механизм устанавливается строго вверх или вбок. Монтаж газового клапана механизмом вниз не
                        допускается.</p>
                    <p>Dungs ZRDLE: <span class="font-weight-bold" style="font-size:0.8rem;">ZRDLE 407 5, ZRDLE 410 5, ZRDLE 415 5, ZRDLE 420 5, ZRDLE 4040 5, ZRDLE 4050 5.</span>
                    </p>
                </div>
              	<div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="tabs-for-products">
            <div class="row">
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark" style="border-bottom: none;"><h5>
                        ZRL</h5>
                </div>
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark"
                     style="border-bottom: none; background:black; color:white;"><h5>ZRLE</h5>
                </div>
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark tabs-for-products-bookmark-right"
                     style="border-bottom: none; background:black; color:white;"><h5>ZRDLE</h5>
                </div>
            </div>


            <!--Первое поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRL">
                            <h4>ZRD 407 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 30 м 3 /час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRL">
                            <h4>ZRD 410 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 46 м 3 /час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRL">
                            <h4>ZRD 415 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 90 м 3 /час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRL">
                            <h4>ZRD 420 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец первого поля карточки-->


            <!--Второе поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRLE">
                            <h4>ZRLE 407 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 30 м 3 /час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRLE">
                            <h4>ZRLE 410 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 46 м 3 /час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRLE">
                            <h4>ZRLE 415 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 90 м 3 /час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRLE">
                            <h4>ZRLE 420 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец второго поля карточки-->


            <!--Третье поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRDLE">
                            <h4>ZRDLE 407 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 30 м 3 /час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRDLE">
                            <h4>ZRDLE 410 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 46 м 3 /час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRDLE">
                            <h4>ZRDLE 415 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 90 м 3 /час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRDLE">
                            <h4>ZRDLE 420 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRDLE">
                            <h4>ZRDLE 4040 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 90 м 3 /час</li>
                                <li>Соединение: DN 40′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/zrd.png" class="img-fluid" alt="Dungs ZRDLE">
                            <h4>ZRDLE 4050 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: DN 50′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--Конец третьего поля карточки-->


        </div>
    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	