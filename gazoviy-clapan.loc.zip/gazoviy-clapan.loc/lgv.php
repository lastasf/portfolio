<?php
require "title.php";
$title = "$model3Title";
$description = "$model3Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/lgv">Газовые клапаны Dungs LGV</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Газовые клапаны Dungs LGV</span>
        </h1>
        <div class="line-style"></div>
        <div class="row">
            <div class="col-lg-4 my-5">
                <div class="slides-product-container">
                    <div class="slides-product text-center mb-3">
                        <img class="img-fluid" src="img/products/lgv-3-1.png" alt="Dungs MV купить">
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-4">
                    <div class="slides-product-min">
                       
                    </div>
                </div>               
            </div>
            <div class="col-lg-8 my-3 px-lg-5">
                <div class="product-description">
                    <h3>Описание Dungs  LGV</h3>
                    <p>Dungs LGV это электромагнитный клапан блокировки для прекращения подачи газа. Максимальное рабочее давление составляет 500 мбар и отличается быстрым открытием и закрытием.  Кроме того, модель предусматривает возможность дополнительного оснащения клапана датчика положения.</p>
                    <p>Dungs LGV: <span class="font-weight-bold" style="font-size:0.8rem;">LGV 507 5.</span></p>
                </div>
                <div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="tabs-for-products">
            <div class="row">
                <div class="col-lg-12 col-dek text-center tabs-for-products-bookmark" style="border-right:none; border-bottom: none;"><h5>LGV</h5></div>
            </div>


            <!--Первое поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/lgv.png" class="img-fluid" alt="Dungs MV 502 1">
                            <h4>LGV 507 5</h4>
                            <ul>
                                <li>Электромагнитный клапан LGV 507/5 119271 фирмы DUNGS</li>
                                <li>Модель: LGV 507/5</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Присоединение: 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец первого поля карточки-->



        </div>
    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	