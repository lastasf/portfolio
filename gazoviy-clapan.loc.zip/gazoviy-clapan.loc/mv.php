<?php
require "title.php";
$title = "$model2Title";
$description = "$model2Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/mv">Газовые клапаны Dungs MV...</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Газовые клапаны Dungs MV</span>
            <span class="h1-product-span" style="display:none;">Газовые клапаны Dungs MVD</span>
            <span class="h1-product-span" style="display:none;">Газовые клапаны Dungs MVDLE</span>
        </h1>
        <div class="line-style"></div>
        <div class="row">
            <div class="col-lg-4 my-5">
                <div class="slides-product-container">
                    <div class="slides-product text-center mb-3">
                        <img class="img-fluid" src="img/products/mv-2-1.png" alt="Dungs MV купить">
                    </div>
                    <div class="slides-product text-center mb-3" style="display:none;">
                        <img class="img-fluid" src="img/products/mv-2-2.png" alt="Газовые клапаны Dungs MVD">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mv-2-1.png" alt="клапаны Dungs MV">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mv-2-2.png" alt="Dungs MVD купить">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 my-3 px-lg-5">
                <div class="product-description">
                    <h3>Описание Dungs MV</h3>
                    <p>Dungs MV - это одноступенчатый клапан для запальной свечи, котла или горелки. Максимальное
                        давление газа составляет 500 мбар, а резьбовое присоединение имеет диаметр подключения Rp 1/4''.
                        Клапан обладает степенью пыле-влагодазащиты по стандарту IP54. Электроподключение газового
                        клапана происходит через штекерное подключение или при помощи кабельного ввода. При проведении
                        обслуживания или любых других работ клапан не должен быть под давлением. После остановки
                        оборудования клапан должен пройти проверку на герметичность.</p>
                    <p>Dungs MV: <span class="font-weight-bold" style="font-size:0.8rem;">MV 502 1.</span>
                    </p>
                </div>
                <div class="product-description" style="display:none;">
                    <h3>Описание Dungs MVD</h3>
                    <p>Dungs MVD - это автоматический одноступенчатый электромагнитный газовый клапан. Модель
                        предназначена для прекращения подачи газа в автоматическом режиме. Клапан отличен быстрым
                        временем открытия, а также нулвым временем отсечки газа. Максимальное рабочее давление
                        составляет 200 мбар для серии MVD2 и 500 мбар для MVD5. Резьбовой тип соединения от Rp 3/8' до
                        Rp 2 '1/2. Фланцевый тип соединения DN40 - DN200. Клапан оборудован встроенным сетчатым
                        фильтром-грязеуловителем, который позволяет защитить исполнительный механизм от загрязнения.</p>
                    <p>Dungs MVD: <span class="font-weight-bold" style="font-size:0.8rem;">MV 502 1, MVD 205 5, MVD 207 5, MVD 210 5, MVD 215 5, MVD 220 5, MVD 503 5, MVD 505 5, MVD 507 5, MVD 510 5, MVD 515 5, MVD 520 5, MVD 2040 5, MVD 2050 5, MVD 2050 5, MVD 2080 5, MVD 2100 5, MVD 2125 5, MVD 2150 5, MVD 5040 5, MVD 5050 5, MVD 5065 5, MVD 5080 5, MVD 5100 5, MVD 5100 5, MVD 5150 5.</span>
                    </p>
                </div>
                <div class="product-description" style="display:none;">
                    <h3>Описание Dungs MVDLE</h3>
                    <p>Dungs MVDLE - это одноступенчатый электромагнитный запорный клапан, предназначенный для защиты
                        горелки или другого газового оборудования. Клапан отличается быстрым открытием, а также
                        медленным закрытием с нулевым временем отсечки. Максимальное рабочее давление составляет 200
                        мбар для серии MVD2 и 500 мбар для MVD5. Резьбовой тип соединения от Rp 3/8' до Rp 2 '1/2.
                        Фланцевый тип соединения DN40 - DN200. Клапан оборудован встроенным сетчатым
                        фильтром-грязеуловителем, который позволяет защитить исполнительный механизм от
                        загрязнения. </p>
                    <p>Dungs MVDLE: <span class="font-weight-bold" style="font-size:0.8rem;">MVDLE 203 5, MVDLE 205 5, MVDLE 207 5, MVDLE 210 5, MVDLE 215 5, MVDLE 220 5, MVDLE 225 5, MVDLE 503 5, MVDLE 507 5, MVDLE 515 5, MVDLE 520 5, MVDLE 2040 5, MVDLE 2050 5, MVDLE 2065 5, MVDLE 2080 5, MVDLE 2100 5, MVDLE 5050 5.</span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="tabs-for-products">
            <div class="row">
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark" style="border-bottom: none;"><h5>
                        MV</h5></div>
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark"
                     style="border-bottom: none; background:black; color:white;"><h5>MVD</h5></div>
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark tabs-for-products-bookmark-right"
                     style="border-bottom: none; background:black; color:white;"><h5>DMV-DLE</h5></div>
            </div>


            <!--Первое поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mv.png" class="img-fluid" alt="Dungs MV 502 1">
                            <h4>MV 502 1</h4>
                            <ul>
                                <li>Электромагнитный клапан MV 502/1 фирмы DUNGS</li>
                                <li>Модель: MV 502/1</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Соединение: Dn 8</li>
                                <li>Электрическое подсоединение: штекер</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец первого поля карточки-->


            <!--Второе поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 203 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 6 м 3 /час</li>
                                <li>Соединение: Rp 3/8′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 205 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 15 м 3 /час</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 207 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 30 м 3 /час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 210 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 46 м 3 /час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 215 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 90 м 3 /час</li>
                                <li>Соединение: Rp 1 1/2</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 220 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 225 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 503 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 6 м 3 /час</li>
                                <li>Соединение: Rp 3/8′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 505 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 15 м 3 /час</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 507 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 30 м 3 /час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 510 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 46 м 3 /час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 515 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 90 м 3 /час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 520 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 2040 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 85 м 3 /час</li>
                                <li>Соединение: DN 40</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 2050 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 135 м 3 /час</li>
                                <li>Соединение: DN 50</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 2065 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 230 м 3 /час</li>
                                <li>Соединение: DN 65</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 2080 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 350 м 3 /час</li>
                                <li>Соединение: DN 80</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 2100 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 550 м 3 /час</li>
                                <li>Соединение: DN 100</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 2125 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 950 м 3 /час</li>
                                <li>Соединение: DN 125</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 2150 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 1500 м 3 /час</li>
                                <li>Соединение: DN 150</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 5040 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 85 м 3 /час</li>
                                <li>Соединение: DN 40</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 5050 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 135 м 3 /час</li>
                                <li>Соединение: DN 50</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 5065 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 230 м 3 /час</li>
                                <li>Соединение: DN 65</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 5080 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 350 м 3 /час</li>
                                <li>Соединение: DN 80</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 5100 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 550 м 3 /час</li>
                                <li>Соединение: DN 100</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 5125 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 950 м 3 /час</li>
                                <li>Соединение: DN 125</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVD 5150 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 1500 м 3 /час</li>
                                <li>Соединение: DN 150</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец второго поля карточки-->


            <!--Третье поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 203 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 6 м3/час</li>
                                <li>Соединение: Rp 3/8′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 205 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 15 м3/час</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 207 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 30 м3/час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 210 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 46 м 3 /час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 215 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 90 м 3 /час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 220 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 225 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 503 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 6 м 3 /час</li>
                                <li>Соединение: Rp 3/8′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 507 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 30 м 3 /час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 515 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 90 м 3 /час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 520 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м 3 /час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 2040 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 85 м 3 /час</li>
                                <li>Соединение: DN 40</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 2050 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 135 м 3 /час</li>
                                <li>Соединение: DN 50</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 2065 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 230 м 3 /час</li>
                                <li>Соединение: DN 65</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 2080 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 350 м 3 /час</li>
                                <li>Соединение: DN 80</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 2100 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 200 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 550 м 3 /час</li>
                                <li>Соединение: DN 100</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mvd-mvdle.png" class="img-fluid" alt="Dungs DMV">
                            <h4>MVDLE 5050 5</h4>
                            <ul>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 135 м 3 /час</li>
                                <li>Соединение: DN 50</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец третьего поля карточки-->


        </div>
    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	