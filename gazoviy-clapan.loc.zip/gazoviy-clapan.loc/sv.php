<?php
require "title.php";
$title = "$model5Title";
$description = "$model5Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/sv">Газовые клапаны Dungs SV...</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Газовые клапаны Dungs SV</span>
            <span class="h1-product-span" style="display:none;">Газовые клапаны Dungs SV-D</span>
            <span class="h1-product-span" style="display:none;">Газовые клапаны Dungs SV-DLE</span>
        </h1>
        <div class="line-style"></div>
        <div class="row">
            <div class="col-lg-4 my-5">
                <div class="slides-product-container">
                    <div class="slides-product text-center mb-5">
                        <img class="img-fluid" src="img/products/sv-5-1.png" alt="Dungs SV купить">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="slides-product-min">

                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 my-3 px-lg-5">
                <div class="product-description">
                    <h3>Описание Dungs SV</h3>
                    <p>Dungs SV - это серия газовых клапанов с увеличенной пропускной способностью и
                        энергоэффективностью.
                        Клапан серии SV оснащен повышенной влагостойкостью и пылезащищенностью IP65. Эргономическая
                        конструкция позволяет установить датчик-реле давления GW-A5. Простая и быстрая установка клапана
                        обеспечивается за счет переходного монтажного фланца с трубной резьбой на входе. Резьбовое
                        соединение Rp 1/2' до 2'. Рабочее давление газа до 500 мбар.</p>
                    <p>Dungs SV: <span class="font-weight-bold" style="font-size:0.8rem;">SV 505, SV 507, SV 510, SV 512, SV 515, SV 520.</span>
                    </p>
                </div>
                <div class="product-description" style="display:none;">
                    <h3>Описание Dungs SV-D</h3>
                    <p>Dungs SV-D - это автоматические газовые клапаны повышенной пропускной способностью и
                        энергоэффективностью. Клапан обладает повышенной влагостойкостью и пылезащищенностью по типу
                        защиту IP65. Модель оснащена дросселем расхода газа, а эргономичная конструкция позволит
                        установить датчик-реле давления газа GW-A5 который монтируется при помощи переходных фланцев для
                        перехода на резьбовое присоединение от Rp 1/2' до Rp 2'.</p>
                    <p>Dungs SV-D: <span class="font-weight-bold" style="font-size:0.8rem;">SV-D 505, SV-D 507, SV-D 510, SV-D 512, SV-D 515, SV-D 520.</span>
                    </p>
                </div>
                <div class="product-description" style="display:none;">
                    <h3>Описание Dungs SV-DLE</h3>
                    <p>Dungs SV-DLE - это газовый клапан класса А группа 2, обладающий повышенной пропускной
                        способностью и энергоэффективностью. Клапан отличен быстрым открытием, а также медленным
                        открытием с опцией регулировки стартового расхода газа. Модель оснащена дросселем расхода газа,
                        а эргономичная конструкция позволит установить датчик реле давления газа GW-A5 для легкого
                        монтажа при помощи присоединительного фланца. Монтаж клапанов осуществляется при помощи
                        переходных фланцев, которые позволяют выполнить переход на резьбовое присоединение от Rp 1/2' до
                        Rp 2'. Максимальное рабочее давление газа составляет 500 мбар.</p>
                    <p>Dungs SV-DLE: <span class="font-weight-bold" style="font-size:0.8rem;">SV-DLE 505, SV-DLE 507, SV-DLE 510, SV-DLE 512, SV-DLE 515, SV-DLE 520.</span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="tabs-for-products">
            <div class="row">
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark" style="border-bottom: none;"><h5>
                        SV</h5>
                </div>
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark"
                     style="border-bottom: none; background:black; color:white;"><h5>SV-D</h5>
                </div>
                <div class="col-lg-4 col-dek text-center tabs-for-products-bookmark tabs-for-products-bookmark-right"
                     style="border-bottom: none; background:black; color:white;"><h5>SV-DLE</h5>
                </div>
            </div>


            <!--Первое поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV">
                            <h4>SV 505</h4>
                            <ul>
                                <li>Электромагнитный клапан SV 505 фирмы DUNGS</li>
                                <li>Модель: SV 505</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 22 м3/час</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV">
                            <h4>SV 507</h4>
                            <ul>
                                <li>Электромагнитный клапан SV 507 фирмы DUNGS</li>
                                <li>Модель: SV 507</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 32 м3/час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV">
                            <h4>SV 510</h4>
                            <ul>
                                <li>Электромагнитный клапан SV 510 фирмы DUNGS</li>
                                <li>Модель: SV 510</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 68 м3/час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV">
                            <h4>SV 512</h4>
                            <ul>
                                <li>Электромагнитный клапан SV 512 фирмы DUNGS</li>
                                <li>Модель: SV 512</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 87 м 3 /час</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV">
                            <h4>SV 515</h4>
                            <ul>
                                <li>Электромагнитный клапан SV 515 фирмы DUNGS</li>
                                <li>Модель: SV 515</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV">
                            <h4>SV 520</h4>
                            <ul>
                                <li>Электромагнитный клапан SV 520 фирмы DUNGS</li>
                                <li>Модель: SV 520</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м3/час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец первого поля карточки-->


            <!--Второе поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-D">
                            <h4>SV-D 505</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-D 505 фирмы DUNGS</li>
                                <li>Модель: SV-D 505</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 22 м3/час</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-D">
                            <h4>SV-D 507</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-D 507 фирмы DUNGS</li>
                                <li>Модель: SV-D 507</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 32 м3/час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-D">
                            <h4>SV-D 510</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-D 510 фирмы DUNGS</li>
                                <li>Модель: SV-D 510</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 68 м3/час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-D">
                            <h4>SV-D 512</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-D 512 фирмы DUNGS</li>
                                <li>Модель: SV-D 512</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 87 м3/час</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-D">
                            <h4>SV-D 515</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-D 515 фирмы DUNGS</li>
                                <li>Модель: SV-D 515</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-D">
                            <h4>SV-D 520</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-D 520 фирмы DUNGS</li>
                                <li>Модель: SV-D 520</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150м 3/час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец второго поля карточки-->


            <!--Третье поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-DLE">
                            <h4>SV-DLE 505</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-DLE 505 фирмы DUNGS</li>
                                <li>Модель: SV-DLE 505</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 22 м3/час</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-DLE">
                            <h4>SV-DLE 507</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-DLE 507 фирмы DUNGS</li>
                                <li>Модель: SV-DLE 507</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 32 м3/час</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-DLE">
                            <h4>SV-DLE 510</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-DLE 510 фирмы DUNGS</li>
                                <li>Модель: SV-DLE 510</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 68 м3/час</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-DLE">
                            <h4>SV-DLE 512</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-DLE 512 фирмы DUNGS</li>
                                <li>Модель: SV-DLE 512</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 87 м3/час</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-DLE">
                            <h4>SV-DLE 515</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-DLE 515 фирмы DUNGS</li>
                                <li>Модель: SV-DLE 515</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/sv.png" class="img-fluid" alt="Dungs SV-DLE">
                            <h4>SV-DLE 520</h4>
                            <ul>
                                <li>Электромагнитный клапан SV-DLE 520 239440 фирмы DUNGS</li>
                                <li>Модель: SV-DLE 520</li>
                                <li>Макс. рабочее давление: 500 мбар</li>
                                <li>Расход газа при перепаде р=10 мбар: 150 м3/час</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец третьего поля карточки-->


        </div>
    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	