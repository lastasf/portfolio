<?php
require "title.php";
$title = "$model6Title";
$description = "$model6Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/mb-dle">Газовые мультиблоки Dungs MB-DLE</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Газовые мультиблоки Dungs MB-DLE</span>
        </h1>
        <div class="line-style"></div>
        <div class="row">
            <div class="col-lg-4 my-5">
                <div class="slides-product-container">
                    <div class="slides-product text-center mb-3">
                        <img class="img-fluid" src="img/products/mb-dle-6-1.png" alt=" MB-DLE купить">
                    </div>
                    <div class="slides-product text-center mb-3" style="display:none;">
                        <img class="img-fluid" src="img/products/mb-dle-6-2.png" alt="Dungs MB-DLE купить">
                    </div>
                    <div class="slides-product text-center mb-3" style="display:none;">
                        <img class="img-fluid" src="img/products/mb-dle-6-3.png" alt="Dungs MB-DLE">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mb-dle-6-1.png" alt="Dungs MB-DLE">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mb-dle-6-2.png" alt="Dungs MB-DLE купить">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mb-dle-6-3.png" alt="Dungs MB-DLE">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 my-3 px-lg-5">
                <div class="product-description">
                    <h3>Описание Dungs MB-DLE</h3>
                    <p>Dungs MB-DLE - это одноступенчатый газовый мультиблок, оснащенный двумя автоматическими
                        клапанами.
                        Первый клапан обладает плавным открытием и обеспечит безопасный пуск горелки. Максимально
                        допустимое давление входного гала составляет 360 мбар. Мультиблок присоединяется при помощи
                        резьбовых фланцев. Резьбовой фланец Rp 1/2' до Rp 2 может использоваться для горелок малой и
                        средней мощности. От попадания пыли и грязи защитит фильтр тонкой очистки из подводящего
                        газопровода.</p>
                    <p>Dungs MB-DLE:
                        <span class="font-weight-bold" style="font-size:0.8rem;">MB-DLE 403 B01 S20, MB-DLE 403 B01 S50, MB-DLE 405 B01 S20, MB-DLE 405 B01 S22, MB-DLE 405 B01 S50, MB-DLE 407 B01 S20, MB-DLE 407 B01 S22, MB-DLE 407 B01 S50, MB-DLE 407 B01 S52, MB-DLE 410 B01 S20, MB-DLE 410 B01 S22, MB-DLE 410 B01 S50, MB-DLE 410 B01 S52, MB-DLE 412 B01 S20, MB-DLE 412 B01 S22, MB-DLE 412 B01 S50, MB-DLE 412 B01 S52, MB-DLE 415 B01 S20, MB-DLE 415 B01 S22, MB-DLE 415 B01 S50, MB-DLE 415 B01 S52, MB-DLE 420 B01 S20, MB-DLE 420 B01 S22, MB-DLE 420 B01 S50, MB-DLE 420 B01 S52.</span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="tabs-for-products">

            <!--Первое поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 403 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 3/8′ </li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 403 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 3/8′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 405 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                     </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 405 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 405 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 407 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 407 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 407 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 407 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 3/4”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 410 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 410 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 410 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 410 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 1”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 412 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 412 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 412 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-05-12.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 412 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 3/4”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-15-20.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 415 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-15-20.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 415 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-15-20.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 415 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 20-50 мбар</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-15-20.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 415 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 20-50 мбар</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-15-20.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 420 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-15-20.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 420 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-15-20.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 420 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 20-50 мбар</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-dle-15-20.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-DLE 420 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 20-50 мбар</li>
                                <li>Соединение: Rp 2'</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Конец первого поля карточки-->


        </div>
    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	