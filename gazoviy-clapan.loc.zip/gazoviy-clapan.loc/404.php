<?php	
	require "title.php";
	$title = "$oschibkaTitle";
	$description = "$oschibkaDescription";
	$headerClass = "header-other-pages";
	$mainPage = "/";
	require "header.php";			
?>

<section class="page-not-found py-60">
	<div class="container py-90">
		<div class="row py-90">
			<div class="col-md-8 offset-md-2 text-center py-90">
				<div class="not-found">
					<h2>404</h2>
					<h3>ошибка</h3>
					<p>Извините. Запрашиваемая страница не найдена!<br>Перейти на <a href="/"><u>главную страницу</u></a></p><br>
				</div>
			</div>
		</div>
	</div>
</section>

<?php	
	require "footer.php";
?>