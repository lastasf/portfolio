<?php
require "title.php";
$title = "$model10Title";
$description = "$model10Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/spare-parts">Запчасти</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Запчасти</span>
        </h1>
        <div class="line-style"></div>

        <h4>Штекер электроподключения</h4>
        <div class="row">
            <div class="col-lg-2 text-center">
                <img class="img-fluid" src="img/products/dungs-1.png" alt="Штекер Dungs">
            </div>
            <div class="col-lg-10 px-lg-5 mt-4">
                <table class="table table-hover table-bordered table-spare-parts mb-0">
                    <tr class="thead-dark"><th>Наименование</th><th>Артикул</th></tr>
                    <tr><td>Штекер для клапана 3-х контактный "черный"</td><td>210319</td></tr>
                </table>
            </div>
            <div class="row py-4 text-center consultation w-100 mx-3 mx-lg-5 mb-5">
                <div class="col-md-8 col-sm-12"><h2>Подобрать запчасти!</h2></div>
                <div class="col-md-4 col-sm-12"><a data-toggle="modal" data-target="#myModal" href="#" class="btn">ОТПРАВИТЬ ЗАЯВКУ</a></div>
            </div>
        </div>
        <h4>Указатель положения "закрыто"</h4>
        <div class="row">
            <div class="col-lg-2 text-center">
                <img class="img-fluid" src="img/products/dungs-2.png" alt="Dungs купить москва">
            </div>
            <div class="col-lg-10 px-lg-5 mt-4">
                <table class="table table-hover table-bordered table-spare-parts mb-0">
                    <tr class="thead-dark"><th>Наименование</th><th>Артикул</th></tr>
                    <tr><td>Указатель положения "закрыто" K01/1</td><td>211202</td></tr>
                </table>
            </div>
            <div class="row py-4 text-center consultation w-100 mx-3 mx-lg-5 mb-5">
                <div class="col-md-8 col-sm-12"><h2>Подобрать запчасти!</h2></div>
                <div class="col-md-4 col-sm-12"><a data-toggle="modal" data-target="#myModal" href="#" class="btn">ОТПРАВИТЬ ЗАЯВКУ</a></div>
            </div>
        </div>
        <h4>Гидротормоз для клапан</h4>
        <div class="row">
            <div class="col-lg-2 text-center">
                <img class="img-fluid" src="img/products/dungs-4.png" alt="Dungs купить">
            </div>
            <div class="col-lg-10 px-lg-5 mt-4">
                <table class="table table-hover table-bordered table-spare-parts mb-0">
                    <tr class="thead-dark"><th>Модель клапана</th><th>№ Гидротормоза</th><th>Артикул</th></tr>
                    <tr><td>MVDLE 225/5</td><td>H10</td><td>223157</td></tr>
                    <tr><td>MVDLE 2065/5 - 2100/5</td><td>H10</td><td>223157</td></tr>
                    <tr><td>DMV-DLE 5100/11 - 5125/11</td><td>H10</td><td>223157</td></tr>
                    <tr><td>MVDLE 207/5 - 2050/5</td><td>H11</td><td>223158</td></tr>
                    <tr><td>MVDLE 507/5 -5050/5</td><td>H11</td><td>223158</td></tr>
                    <tr><td>ZRLE/ZRDLE 407/5 - 4050/5</td><td>H11</td><td>223158</td></tr>
                    <tr><td>DMV-DLE 525/11</td><td>H11</td><td>223158</td></tr>
                    <tr><td>DMV-DLE 5065/11 - 5080/11</td><td>H11</td><td>223158</td></tr>
                    <tr><td>MVDLE 203/5 - 205/5</td><td>H12/3</td><td>223159</td></tr>
                    <tr><td>MVDLE 503/5 - 505/5</td><td>H12/3</td><td>223159</td></tr>
                    <tr><td>DMV-DLE 5040/11 - 5050/11</td><td>H12/6</td><td>224457</td></tr>
                    <tr><td>DMV-DLE 507 - 520/11</td><td>H12/6</td><td>224457</td></tr>
                    <tr><td>DMV-DLE 503/11</td><td>H13</td><td>224455</td></tr>
                </table>
            </div>
            <div class="row py-4 text-center consultation w-100 mx-3 mx-lg-5 mb-5">
                <div class="col-md-8 col-sm-12"><h2>Подобрать запчасти!</h2></div>
                <div class="col-md-4 col-sm-12"><a data-toggle="modal" data-target="#myModal" href="#" class="btn">ОТПРАВИТЬ ЗАЯВКУ</a></div>
            </div>
        </div>
        <h4>Фланцы для клапанов</h4>
        <div class="row">
            <div class="col-lg-2 text-center">
                <img class="img-fluid" src="img/products/dungs-3.png" alt="Dungs купить">
            </div>
            <div class="col-lg-10 px-lg-5 mt-4">
                <table class="table table-hover table-bordered table-spare-parts mb-0">
                    <tr class="thead-dark"><th>Обозначение</th><th>Клапан</th><th>Присоединение</th><th>Артикул</th></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 503/11</td><td>Rp 3/8</td><td>217471</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 503/11</td><td>Rp 1/2</td><td>217472</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 507/11</td><td>Rp 1/2</td><td>222341</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 507/11</td><td>Rp 3/4</td><td>222342</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 507/11</td><td>Rp 1</td><td>222001</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 507/11</td><td>Rp 1 1/4</td><td>240506</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 512/11, DMV-D(LE) 520/11</td><td>Rp 1</td><td>222343</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 512/11, DMV-D(LE) 520/11</td><td>Rp 1 1/4</td><td>222344</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 512/11, DMV-D(LE) 520/11</td><td>Rp 1 1/2</td><td>221884</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 512/11, DMV-D(LE) 520/11</td><td>Rp 2</td><td>221926</td></tr>
                    <tr><td>Фланец</td><td>DMV-D(LE) 525/11</td><td>Rp 2</td><td>215384</td></tr>
                    <tr><td>Фланец с ниппилем</td><td>DMV-D(LE) 507/11</td><td>Rp 1/2</td><td>241953</td></tr>
                    <tr><td>Фланец с ниппилем</td><td>DMV-D(LE) 507/11</td><td>Rp 3/4</td><td>231230</td></tr>
                    <tr><td>Фланец с ниппилем</td><td>DMV-D(LE) 507/11</td><td>Rp 1</td><td>231231</td></tr>
                    <tr><td>Фланец с ниппилем</td><td>DMV-D(LE) 512/11,DMV-D(LE) 520/11</td><td>Rp 1</td><td>241956</td></tr>
                    <tr><td>Фланец с ниппилем</td><td>DMV-D(LE) 512/11, DMV-D(LE) 520/11</td><td>Rp 1 1/4</td><td>231232</td></tr>
                    <tr><td>Фланец с ниппилем</td><td>DMV-D(LE) 512/11, DMV-D(LE) 520/11</td><td>Rp 1 1/2</td><td>225528</td></tr>
                    <tr><td>Фланец с ниппелем</td><td>DMV-D(LE) 512/11,DMV-D(LE) 520/11</td><td>Rp 2</td><td>225532</td></tr>
                    <tr><td>Фланец с ниппелем</td><td>DMV-D(LE) 525/11</td><td>Rp 2</td><td>225531</td></tr>
                    <tr><td>Фланец запальной линии</td><td>DMV-D(LE) 5040-5125</td><td>G 3/4</td><td>219006</td></tr>
                    <tr><td>Фланец запальной линии</td><td>DMV-D(LE) 507-520</td><td>G 1/2</td><td>219007</td></tr>
                </table>
            </div>
            <div class="row py-4 text-center consultation w-100 mx-3 mx-lg-5 mb-5">
                <div class="col-md-8 col-sm-12"><h2>Подобрать запчасти!</h2></div>
                <div class="col-md-4 col-sm-12"><a data-toggle="modal" data-target="#myModal" href="#" class="btn">ОТПРАВИТЬ ЗАЯВКУ</a></div>
            </div>
        </div>

        <h4>Плата управления катушки</h4>
        <div class="row">
            <div class="col-lg-2 text-center">
                <img class="img-fluid" src="img/products/dungs-5.png" alt="Dungs купить">
            </div>
            <div class="col-lg-10 px-lg-5 mt-4">
                <table class="table table-hover table-bordered table-spare-parts mb-0">
                    <tr class="thead-dark"><th>Обозначение</th><th>Оборудование</th><th>Артикул</th></tr>
                    <tr><td>Плата управления Magnet Nr.1011(Плата управления Катушка №1011)</td><td>DMV-D 503/11</td><td>266141</td></tr>
                    <tr><td>Плата управления Magnet Nr.1111(Плата управления Катушка №1111)</td><td>DMV-D 507/11</td><td>266144</td></tr>
                    <tr><td>Плата управления Magnet Nr.1211(Плата управления катушка №1211)</td><td>DMV-D 512/11</td><td>266147</td></tr>
                    <tr><td>Плата управления Magnet Nr.1212(Плата управления Катушка №1212)</td><td>DMV-D 520/11</td><td>266147</td></tr>
                    <tr><td>Плата управления Magnet Nr.1411(Плата управления Катушка №1411)</td><td>DMV-D 525/11</td><td>266147</td></tr>
                    <tr><td>Плата управления Magnet Nr.1212(Плата управления Катушка №1212)</td><td>DMV-D 5040/11</td><td>266147</td></tr>
                    <tr><td>Плата управления Magnet Nr.1212(Плата управления Катушка №1212)</td><td>DMV-D 5050/11</td><td>266147</td></tr>
                    <tr><td>Плата управления Magnet Nr.1411(Плата управления Катушка №1411)</td><td>DMV-D 5065/11</td><td>266147</td></tr>
                    <tr><td>Плата управления Magnet Nr.1511(Плата управления Катушка №1511)</td><td>DMV-D 5080/11</td><td>266147</td></tr>
                    <tr><td>Плата управления Magnet Nr.1611(Плата управления Катушка №1611)</td><td>DMV-D 5100/11</td><td>266148</td></tr>
                    <tr><td>Плата управления Magnet Nr.1711(Плата управления Катушка №1711)</td><td>DMV-D 5125/11</td><td>266148</td></tr>
                    <tr><td>Плата управления Magnet Nr.1411/2P(Плата управления Катушка №1411/2P</td><td>DMV 525/11 eco,DMV-D 525/11 eco,DMV 5065/11 eco,DMV-D 5065/11 eco,DMV 525/12,DMV-D 525/12</td><td>208872</td></tr>
                    <tr><td>Плата управления Magnet Nr.1511/2P(Плата управления Катушка №1511/2P)</td><td>DMV 5080/11 eco,DMV-D 5080/11 eco,DMV 5065/12,DMV-D 5065/12</td><td>248492</td></tr>
                    <tr><td>Плата управления Magnet Nr.1611/2P(Плата управления Катушка №1611/2P)</td><td>DMV 5100/11 eco,DMV-D 5100/11 eco,DMV 5080/12,DMV-D 5080/12</td><td>248492</td></tr>
                    <tr><td>Плата управления Magnet Nr.1711/2P(Плата управления Катушка №1711/2P)</td><td>DMV 5125/11 eco,DMV-D 5125/11 eco,DMV 5100/12,DMV-D 5100/12</td><td>248492</td></tr>
                    <tr><td>Плата управления Magnet Nr.1811/2P(Плата управления Катушка Nr.1811/2P)</td><td>DMV 5125/12,DMV-D 5125/12</td><td>248492</td></tr>
                    <tr><td>Плата управления Magnet Nr.1411/2PL(Плата управления Катушка Nr.1411/2PL)</td><td>DMV-DLE 5065/11 eco</td><td>208872</td></tr>
                    <tr><td>Плата управления Magnet Nr.1511/2PL(Плата управления Катушка Nr.1511/2PL)</td><td>DMV-DLE 5080/11 eco</td><td>248493</td></tr>
                    <tr><td>Плата управления Magnet Nr.1611/2PL(Плата управления Катушка Nr.1611/2PL)</td><td>DMV-DLE 5100/11 eco</td><td>248493</td></tr>
                    <tr><td>Плата управления Magnet Nr.1611/2PL(Плата управления Катушка Nr.1611/2PL)</td><td>DMV-DLE 5100/11 eco</td><td>248493</td></tr>
                    <tr><td>Плата управления Magnet Nr.1711/2PL(Плата управления Катушка Nr.1711/2PL)</td><td>DMV-DLE 5125/11 eco</td><td>248493</td></tr>
                    <tr><td>Плата управления Magnet Nr.100, 110, 150, 160, 200, 210, 290, 310 (Плата управления Катушка Nr.100, 110, 150, 160, 200, 210, 290, 310)</td><td>Для LGV, MVD(LE)</td><td>231409</td></tr>
                    <tr><td>Плата управления Magnet Nr.280, 300, 410 (Плата управления Катушка Nr.280, 300, 410)</td><td>Для MVD(LE)</td><td>231410</td></tr>
                    <tr><td>Плата управления Magnet Nr.400, 500, 550 (Плата управления Катушка Nr. 400, 500, 550)</td><td>Для MVD(LE)</td><td>231412</td></tr>
                </table>
            </div>
            <div class="row py-4 text-center consultation w-100 mx-3 mx-lg-5 mb-5">
                <div class="col-md-8 col-sm-12"><h2>Подобрать запчасти!</h2></div>
                <div class="col-md-4 col-sm-12"><a data-toggle="modal" data-target="#myModal" href="#" class="btn">ОТПРАВИТЬ ЗАЯВКУ</a></div>
            </div>
        </div>

        <h4>Электромагнитные катушки для клапанов</h4>
        <div class="row">
            <div class="col-lg-2 text-center">
                <img class="img-fluid" src="img/products/dungs-6.png" alt="Dungs купить москва">
            </div>
            <div class="col-lg-10 px-lg-5 mt-4">
                <table class="table table-hover table-bordered table-spare-parts mb-0">
                    <tr class="thead-dark"><th>Катушка индуктивности (Magnet Nr) для электромагнитных и двойных клапанов DUNGS</th><th>№ соленоида</th><th>Артикул</th></tr>
                    <tr><td>SV- 505/507</td><td>Magnet Nr.20(Катушка №20)</td><td>243586</td></tr>
                    <tr><td>SV- 510/515</td><td>Magnet Nr.30 (Катушка №30)</td><td>243587</td></tr>
                    <tr><td>SV- 520</td><td>Magnet Nr.50 (Катушка №50)</td><td>243588</td></tr>
                    <tr><td>MVD(LE) 203/5 -205/5</td><td>Magnet Nr.100 (Катушка №100)</td><td>214206</td></tr>
                    <tr><td>MVD 503/5-505/5</td><td>Magnet Nr.100 (Катушка №100)</td><td>214206</td></tr>
                    <tr><td>MVDLE 503/5</td><td>Magnet Nr.100 (Катушка №100)</td><td>214206</td></tr>
                    <tr><td>LGV 507</td><td>Magnet Nr.100 (Катушка №100)</td><td>214206</td></tr>
                    <tr><td>MVDLE 505/5</td><td>Magnet Nr.120 (Катушка №120)</td><td>225790</td></tr>
                    <tr><td>MVD 207/5</td><td>Magnet Nr.150 (Катушка №150)</td><td>211356</td></tr>
                    <tr><td>MVDLE 207/5</td><td>Magnet Nr.200 (Катушка №200)</td><td>214207</td></tr>
                    <tr><td>MVD(LE) 210/5</td><td>Magnet Nr.200 (Катушка №200)</td><td>214207</td></tr>
                    <tr><td>MVD(LE) 507/5</td><td>Magnet Nr.200 (Катушка №200)</td><td>214207</td></tr>
                    <tr><td>MVD 510/5</td><td>Magnet Nr.200 (Катушка №200)</td><td>214207</td></tr>
                    <tr><td>MVDLE 510/5</td><td>Magnet Nr.250 (Катушка №250)</td><td>225787</td></tr>
                    <tr><td>MVD(LE) 215/5</td><td>Magnet Nr.280 (Катушка №280)</td><td>213407</td></tr>
                    <tr><td>MVD (LE) 2040/5</td><td>Magnet Nr.280 (Катушка №280)</td><td>213407</td></tr>
                    <tr><td>MVD(LE) 215/5-220/5</td><td>Magnet Nr.300 (Катушка №300)</td><td>214208</td></tr>
                    <tr><td>MVD(LE) 515/5</td><td>Magnet Nr.300 (Катушка №300)</td><td>214208</td></tr>
                    <tr><td>MVD(LE) 2040/5-2050/5</td><td>Magnet Nr.300 (Катушка №300)</td><td>214208</td></tr>
                    <tr><td>MVD(LE) 5040/5</td><td>Magnet Nr.300 (Катушка №300)</td><td>214208</td></tr>
                    <tr><td>MVD(LE) 225/5</td><td>Magnet Nr.400 (Катушка №400)</td><td>214209</td></tr>
                    <tr><td>MVD(LE) 520/5</td><td>Magnet Nr.400 (Катушка №400)</td><td>214209</td></tr>
                    <tr><td>MVD(LE) 2065/5</td><td>Magnet Nr.400 (Катушка №400)</td><td>214209</td></tr>
                    <tr><td>MVD(LE) 5050/5</td><td>Magnet Nr.400 (Катушка №400)</td><td>214209</td></tr>
                    <tr><td>MVD 525/5</td><td>Magnet Nr.500 (Катушка №500)</td><td>214210</td></tr>
                    <tr><td>MVD(LE) 2080/5</td><td>Magnet Nr.500 (Катушка №500)</td><td>214210</td></tr>
                    <tr><td>MVD 5065/5</td><td>Magnet Nr.500 (Катушка №500)</td><td>214210</td></tr>
                    <tr><td>MVD(LE) 2100/5</td><td>Magnet Nr.500 (Катушка №500)</td><td>214210</td></tr>
                    <tr><td>MVD 5080/5</td><td>Magnet Nr.500 (Катушка №500)</td><td>214210</td></tr>
                    <tr><td>MVD 2100/5</td><td>Magnet Nr.550 (Катушка №550)</td><td>214211</td></tr>
                    <tr><td>MVD 4100/5</td><td>Magnet Nr.550 (Катушка №550)</td><td>214211</td></tr>
                    <tr><td>MVD 5080/5</td><td>Magnet Nr.550 (Катушка №550)</td><td>214211</td></tr>
                    <tr><td>MVDLE 2100/5</td><td>Magnet Nr.550 (Катушка №550)</td><td>214211</td></tr>
                    <tr><td>MVDLE 4100/5</td><td>Magnet Nr.550 (Катушка №550)</td><td>214211</td></tr>
                    <tr><td>MVD 5100/5</td><td>Magnet Nr.60E (Катушка №60E)</td><td>214212</td></tr>
                    <tr><td>MVD 2125/5</td><td>Magnet Nr.60E (Катушка №60E)</td><td>214212</td></tr>
                    <tr><td>MVD 5125/5</td><td>Magnet Nr.60E (Катушка №60E)</td><td>214212</td></tr>
                    <tr><td>MVD 5150/5</td><td>Magnet Nr.61E (Катушка №61E)</td><td>214213</td></tr>
                    <tr><td>MVD 2150/5</td><td>Magnet Nr.61E (Катушка №61E)</td><td>214213</td></tr>
                    <tr><td>MVD 2200/5</td><td>Magnet Nr.70E (Катушка №70E)</td><td>223332</td></tr>
                    <tr><td>DMV 503/11</td><td>Magnet Nr.1011 (Катушка №1011)</td><td>224980</td></tr>
                    <tr><td>DMV 507/11</td><td>Magnet Nr.1111 (Катушка №1111)</td><td>225000</td></tr>
                    <tr><td>DMV 512/11</td><td>Magnet Nr.1211 (Катушка №1211)</td><td>225004</td></tr>
                    <tr><td>DMV 5040/11</td><td>Magnet Nr.1211 (Катушка №1211)</td><td>225004</td></tr>
                    <tr><td>DMV 520/11</td><td>Magnet Nr.1212 (Катушка №1212)</td><td>225048</td></tr>
                    <tr><td>DMV 5050/11</td><td>Magnet Nr.1212 (Катушка №1212)</td><td>225048</td></tr>
                    <tr><td>DMV 525/11</td><td>Magnet Nr.1411 (Катушка №1411)</td><td>225167</td></tr>
                    <tr><td>DMV 5065/11</td><td>Magnet Nr.1411 (Катушка №1411)</td><td>225167</td></tr>
                    <tr><td>DMV 5080/11</td><td>Magnet Nr.1511 (Катушка №1511)</td><td>225171</td></tr>
                    <tr><td>DMV 5100/11</td><td>Magnet Nr.1611 (Катушка №1611)</td><td>225220</td></tr>
                    <tr><td>DMV 5125/11</td><td>Magnet Nr.1711 (Катушка №1711)</td><td>225225</td></tr>
                    <tr><td>ZRDLE 407/5</td><td>Magnet Nr.25.1 (Катушка №25.1)</td><td>216877</td></tr>
                    <tr><td>ZRDLE 410/5</td><td>Magnet Nr.25.1 (Катушка №25.1)</td><td>216877</td></tr>
                    <tr><td>ZRDLE 4020/5</td><td>Magnet Nr.25.1 (Катушка №25.1)</td><td>216877</td></tr>
                    <tr><td>ZRDLE 4025/5</td><td>Magnet Nr.25.1 (Катушка №25.1)</td><td>216877</td></tr>
                    <tr><td>ZRDLE 415/5</td><td>Magnet Nr.35.1 (Катушка №35.1)</td><td>216878</td></tr>
                    <tr><td>ZRDLE 420/5</td><td>Magnet Nr.35.1 (Катушка №35.1)</td><td>216878</td></tr>
                    <tr><td>ZRDLE 4040/5</td><td>Magnet Nr.35.1 (Катушка №35.1)</td><td>216878</td></tr>
                    <tr><td>ZRDLE 4050/5</td><td>Magnet Nr.35.1 (Катушка №35.1)</td><td>216878</td></tr>
                    <tr><td>DMV 525/11 eco</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>248494</td></tr>
                    <tr><td>DMV-D 525/11 eco</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>248494</td></tr>
                    <tr><td>DMV 5065/11 eco</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>248494</td></tr>
                    <tr><td>DMV-D 5065/11 eco</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>248494</td></tr>
                    <tr><td>DMV 525/12</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>248494</td></tr>
                    <tr><td>DMV 5065/11 eco</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>255477</td></tr>
                    <tr><td>DMV 525/11 eco</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>255477</td></tr>
                    <tr><td>DMV 525/12</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>255477</td></tr>
                    <tr><td>DMV-D 5065/11 eco</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>256629</td></tr>
                    <tr><td>DMV-D 525/11 eco</td><td>Magnet Nr.1411/2P (Катушка №1411/2P)</td><td>256629</td></tr>
                    <tr><td>DMV-DLE 5065/11 eco</td><td>Magnet Nr.1411/2PL (Катушка №1411/2PL)</td><td>256631</td></tr>
                    <tr><td>DMV 5080/11 eco</td><td>Magnet Nr.1511/2P (Катушка №1511/2P)</td><td>247869</td></tr>
                    <tr><td>DMV-D 5080/11 eco</td><td>Magnet Nr.1511/2P (Катушка №1511/2P)</td><td>247869</td></tr>
                    <tr><td>DMV 5065/12</td><td>Magnet Nr.1511/2P (Катушка №1511/2P)</td><td>247869</td></tr>
                    <tr><td>DMV-D 5065/12</td><td>Magnet Nr.1511/2P (Катушка №1511/2P)</td><td>247869</td></tr>
                    <tr><td>DMV-DLE 5080/11 eco</td><td>Magnet Nr.1511/2PL (Катушка №1511/2PL)</td><td>248496</td></tr>
                    <tr><td>DMV-DLE 5065/12</td><td>Magnet Nr.1511/2PL (Катушка №1511/2PL)</td><td>248496</td></tr>
                    <tr><td>DMV 5100/11 eco</td><td>Magnet Nr.1611/2P (Катушка №1611/2P)</td><td>247870</td></tr>
                    <tr><td>DMV-D 5100/11 eco</td><td>Magnet Nr.1611/2P (Катушка №1611/2P)</td><td>247870</td></tr>
                    <tr><td>DMV 5080/12</td><td>Magnet Nr.1611/2P (Катушка №1611/2P)</td><td>247870</td></tr>
                    <tr><td>DMV-D 5080/12</td><td>Magnet Nr.1611/2P (Катушка №1611/2P)</td><td>247870</td></tr>
                    <tr><td>DMV-DLE 5100/11 eco</td><td>Magnet Nr.1611/2PL (Катушка №1611/2PL)</td><td>248498</td></tr>
                    <tr><td>DMV-DLE 5080/12</td><td>Magnet Nr.1611/2PL (Катушка №1611/2PL)</td><td>248498</td></tr>
                    <tr><td>DMV 5125/11 eco</td><td>Magnet Nr.1711/2P (Катушка №1711/2P)</td><td>247871</td></tr>
                    <tr><td>DMV-D 5125/11 eco</td><td>Magnet Nr.1711/2P (Катушка №1711/2P)</td><td>247871</td></tr>
                    <tr><td>DMV 5100/12</td><td>Magnet Nr.1711/2P (Катушка №1711/2P)</td><td>247871</td></tr>
                    <tr><td>DMV-D 5100/12</td><td>Magnet Nr.1711/2P (Катушка №1711/2P)</td><td>247871</td></tr>
                    <tr><td>DMV-DLE 5125/11 eco</td><td>Magnet Nr.1711/2PL (Катушка №1711/2PL)</td><td>248500</td></tr>
                    <tr><td>DMV-DLE 5100/12</td><td>Magnet Nr.1711/2PL (Катушка №1711/2PL)</td><td>248500</td></tr>
                    <tr><td>DMV 5125/12</td><td>Magnet Nr.1811/2P (Катушка №1811/2P)</td><td>247872</td></tr>
                    <tr><td>DMV-D 5125/12</td><td>Magnet Nr.1811/2P (Катушка №1811/2P)</td><td>247872</td></tr>
                </table>
            </div>
            <div class="row py-4 text-center consultation w-100 mx-3 mx-lg-5 mb-5">
                <div class="col-md-8 col-sm-12"><h2>Подобрать запчасти!</h2></div>
                <div class="col-md-4 col-sm-12"><a data-toggle="modal" data-target="#myModal" href="#" class="btn">ОТПРАВИТЬ ЗАЯВКУ</a></div>
            </div>
        </div>
    </div>
</section>


<div class="py-30"></div>

<?php
require "footer.php";
?>	