<?php
require "title.php";
$title = "$model7Title";
$description = "$model7Description";
$headerClass = "header-other-pages";
$mainPage = "/";
require "header.php";
?>

<div class="py-60"></div>

<section class="pt-30 pb-30">
    <div class="container">

        <div class="row">
            <div class="col">
                <div>
                    <ul class="list-unstyled mb-3 d-flex hlebn-kros">
                        <li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
                        <li><a href="/mb-zrdle">Газовые мультиблоки Dungs MB-ZRDLE</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <h1 class="h1-product">
            <span class="h1-product-span">Газовые мультиблоки Dungs MB-DLE</span>
        </h1>
        <div class="line-style"></div>
        <div class="row">
            <div class="col-lg-4 my-5">
                <div class="slides-product-container">
                    <div class="slides-product text-center mb-3">
                        <img class="img-fluid" src="img/products/mb-zrdle-07-01.png" alt=" MB-ZRDLE купить">
                    </div>
                    <div class="slides-product text-center mb-3" style="display:none;">
                        <img class="img-fluid" src="img/products/mb-zrdle-07-02.png" alt="Dungs MB-ZRDLE купить">
                    </div>
                </div>
                <div class="row">
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mb-zrdle-07-01.png" alt="Dungs MB-ZRDLE">
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="slides-product-min">
                            <img class="img-fluid" src="img/products/mb-zrdle-07-02.png" alt="Dungs MB-ZRDLE купить">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-8 my-3 px-lg-5">
                <div class="product-description">
                    <h3>Описание Dungs MB-ZRDLE</h3>
                    <p>Dungs MB-ZRDLE - это двухступенчатый газовый мультиблок с двумя встроенными электромагнитными
                        клапанами. На выходе из клапана мультиблок выполняет функцию стабилизатора. Максимальное рабочее
                        давление на входе в клапан составляет 360 мбар. Второй клапан выполняет плавное открытие и
                        обеспечивает плавную подачу газа в горелку. Эргономичная конструкция предусматривает небольшой
                        вес и малые габаритные размеры.</p>
                    <p>Dungs MB-ZRDLE:
                        <span class="font-weight-bold" style="font-size:0.8rem;">MB-ZRDLE 405 B01 S20, MB-ZRDLE 407 B01 S20, MB-ZRDLE 407 B01 S22, MB-ZRDLE 407 B01 S50, MB-ZRDLE 407 B01 S52, MB-ZRDLE 410 B01 S20, MB-ZRDLE 410 B01 S22, MB-ZRDLE 410 B01 S50, MB-ZRDLE 410 B01 S52, MB-ZRDLE 412 B01 S20, MB-ZRDLE 412 B01 S22, MB-ZRDLE 412 B01 S50, MB-ZRDLE 412 B01 S52, MB-ZRDLE 415 B01 S20, MB-ZRDLE 415 B01 S22, MB-ZRDLE 415 B01 S50, MB-ZRDLE 415 B01 S52, MB-ZRDLE 420 B01 S20, MB-ZRDLE 420 B01 S22, MB-ZRDLE 420 B01 S50, MB-ZRDLE 420 B01 S52.</span>
                    </p>
                </div>
                <div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
            </div>
        </div>
    </div>
</section>

<section>
    <div class="container">
        <div class="tabs-for-products">

            <!--Первое поле карточки-->
            <div class="tabs-for-products-page p-md-5 py-3">
                <div class="row">
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 405 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 407 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 407 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 3/4'</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 407 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 3/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 407 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp3/4”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 410 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 410 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1'</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 410 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 1′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 410 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 1”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 412 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 412 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 1/4”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 412 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 1 1/4′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 412 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-50 мбар</li>
                                <li>Соединение: Rp 1 1/4”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle-415-420.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 415 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle-415-420.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 415 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 1 ½”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle-415-420.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 415 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 20-50 мбар</li>
                                <li>Соединение: Rp 1 1/2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle-415-420.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 415 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 20-50 мбар</li>
                                <li>Соединение: Rp 1 ½”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle-415-420.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 420 B01 S20</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle-415-420.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 420 B01 S22</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 4-20 мбар</li>
                                <li>Соединение: Rp 2”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle-415-420.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 420 B01 S50</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 20-50 мбар</li>
                                <li>Соединение: Rp 2′</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-4">
                        <div class="products-cart">
                            <img src="img/mb-zrdle-415-420.png" class="img-fluid" alt="Dungs MB-DLE">
                            <h4>MB-ZRDLE 420 B01 S52</h4>
                            <ul>
                                <li>Макс. рабочее давление: 360 мбар</li>
                                <li>Диапазон регулирования: 20-50 мбар</li>
                                <li>Соединение: Rp 2”</li>
                            </ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal"
                                 data-target="#myModal">Заказать
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <!--Конец первого поля карточки-->


        </div>
    </div>
</section>

<div class="py-30"></div>

<?php
require "footer.php";
?>	