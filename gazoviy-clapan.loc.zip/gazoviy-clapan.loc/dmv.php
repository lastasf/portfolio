<?php	
	require "title.php";
	$title = "$model1Title";
	$description = "$model1Description";
	$headerClass = "header-other-pages";
	$mainPage = "/";
	require "header.php";
?>

<div class="py-60"></div> 

<section class="pt-30 pb-30">	
	<div class="container">
	
		<div class="row">
			<div class="col">
				<div>
					<ul class="list-unstyled mb-3 d-flex hlebn-kros">
						<li><a href="/"><i class="fa fa-home"></i> Главная</a><span class="px-1">/</span></li>
						<li><a href="/dmv">Газовые клапаны Dungs DMV...</a></li>
					</ul>
				</div>
			</div>
        </div>
	
		<h1 class="h1-product">
			<span class="h1-product-span">Газовые клапаны Dungs DMV</span>
			<span class="h1-product-span" style="display:none;">Газовые клапаны Dungs DMV-D</span>
			<span class="h1-product-span" style="display:none;">Газовые клапаны Dungs DMV-DLE</span>
			<span class="h1-product-span" style="display:none;">Газовые клапаны Dungs DMV-SE</span>	
			<span class="h1-product-span" style="display:none;">Газовые клапаны Dungs DMV-VEF</span>
			
		</h1>
		<div class="line-style"></div>
		<div class="row">
			<div class="col-lg-4 my-5">				
				<div class="slides-product-container">
					<div class="slides-product text-center mb-3">   
					   <img class="img-fluid" src="img/products/dmv-1-1.png" alt="Газовые клапаны Dungs DMV">
					</div>
					<div class="slides-product text-center mb-3" style="display:none;">    
					   <img class="img-fluid" src="img/products/dmv-1-2.png" alt="клапаны Dungs DMV-D">
					</div>
					<div class="slides-product text-center mb-3" style="display:none;">    
					   <img class="img-fluid" src="img/products/dmv-1-3.png" alt="Газовые клапаны Dungs DMV-DLE">
					</div>	
				</div>
				<div class="row">
					<div class="col-4">
						<div class="slides-product-min">
							<img class="img-fluid" src="img/products/dmv-1-1.png" alt="Газовые клапаны Dungs DMV">
						</div>
					</div>
					<div class="col-4">
						<div class="slides-product-min">
							<img class="img-fluid" src="img/products/dmv-1-2.png" alt="клапаны Dungs DMV-D">
						</div>	
					</div>
					<div class="col-4">
						<div class="slides-product-min">
							<img class="img-fluid" src="img/products/dmv-1-3.png" alt="Газовые клапаны Dungs DMV-DLE">
						</div>	
					</div>	
				</div>												
			</div>				
			<div class="col-lg-8 my-3 px-lg-5">
				<div class="product-description">
					<h3>Описание Dungs DMV</h3>
					<p>Dungs DMV - это газовый электромагнитный сочетающий в себе два автоматических газовых клапана размещенных в одном корпусе. Клапаны отличаются высокой степенью быстродействия и дросселем расхода газа. Максимальное рабочее давление составляет 500 мбар. Модель имеет фланцевое соединение  различных диаметров DN 50 – DN 125 и может применяться на горелках средней и промышленной мощности.</p>
					<p>Dungs DMV: <span class="font-weight-bold" style="font-size:0.8rem;">DMV 5065 12, DMV 5080 12, DMV 5100 12, DMV 525 12, DMV 5065 11 ECO, DMV 5080 11 ECO, DMV 5100 11 ECO, DMV 5125 11 ECO, DMV 525 11 ECO.</span></p>
				</div>
				<div class="product-description" style="display:none;">
					<h3>Описание Dungs DMV-D</h3>
					<p>DUNGS DMV-D - это двойной газовые клапан включающий в себя два автоматических запорных клапана располагающихся на одном корпусе. Клапан DMV-D отличается высокой степенью быстродействия, а также оснащен дросселем расхода газа. Максимальное рабочее давление газа составляет 500 мбар. Модель оснащена возможностью вручную ограничить поток газа через регулирования главного потока на клапане. Клапан присоединятся через резьбовое или фланцевое  (от Rp 3/8'' до DN150) присоединение. Такой клапан может применяться как на маломощных, так и на промышленных горелках.</p>
					<p>Dungs DMV-D: <span class="font-weight-bold" style="font-size:0.8rem;">DMV-D 503 11, DMV-D 507 11, DMV-D 512 11, DMV-D 520 11, DMV-D 525 11, DMV-D 5040 11, DMV-D 5050 11, DMV-D 5065 11, DMV-D 5080 11, DMV-D 5100 11, DMV-D 5125 11.</span></p>
				</div>
				<div class="product-description" style="display:none;">
					<h3>Описание Dungs DMV-DLE</h3>
					<p>Dungs DMV-DLE - это двойной электромагнитный клапан включающий в себя пару клапанов  одноступенчатого действия.  Модель  оснащена возможностью  вручную регулировать ограничения подаваемого потока газа через регулирования главного потока. Максимальное давление газа на входе составляет не более 5000 мбар.</p>
					<p>Dungs DMV-DLE: <span class="font-weight-bold" style="font-size:0.8rem;">DMV-DLE 503 11, DMV-DLE 507 11, DMV-DLE 512 11, DMV-DLE 520 11, DMV-DLE 525 11, DMV-DLE 5040, DMV-DLE 5050 11, DMV-DLE 5065 11, DMV-DLE 5080 11, DMV-DLE 5100 11, DMV-DLE 5125 11.</span></p>
				</div>
				<div class="product-description" style="display:none;">
					<h3>Описание Dungs DMV-SE</h3>
					<p>Газовая арматура DMV-SE оснащена встроенным серворегулятором выходного давления газа. Серия предусматривает несколько исполнений позволяя применять их на различное выходное давление.  Рабочее давление клапана составляет не более 500 мбар.  Клапаны выполняют не только подачу или перекрытие газа, но и регулирование давления подаваемое на оборудование. Реле давления устанавливается на корпус клапана.</p>
					<p>Dungs DMV-SE: <span class="font-weight-bold" style="font-size:0.8rem;">DMV-SE 507 11, DMV-SE 512 11, DMV-SE 520 11, DMV-SE 5065 11, DMV-SE 5080 11, DMV-SE 5100 11.</span></p>
				</div>
				<div class="product-description" style="display:none;">
					<h3>Описание Dungs DMV-VEG</h3>
					<p>Клапаны DUNGS серии DMV-VEG оснащены грязеуловителем состоящим их фильтра тонкой очистки и  металлической сетки. Рабочий диапазон клапана составляет 500 мбар и позволит добиться максимально гибкой настройки соотношения газа и воздуха, совместно с расходом при низком перепаде давления.  Для подачи давления в топку имеется устройство регулирования соотношения V и установки нуля. Подключение клапана осуществляется при помощи штекерных разъемов и подходит для установки на горелки малой и средней мощности.</p>
					<p>Dungs DMV-VEG: <span class="font-weight-bold" style="font-size:0.8rem;">DMV-VEF 507 11, DMV-VEF 512 11, DMV-VEF 520 11, DMV-VEF 5065 11, DMV-VEF 5080 11, DMV-VEF 5100 11, DMV-VEF 5125 11.</span></p>
				</div>
				<div class="row">
                    <div class="col-md-6"><a data-toggle="modal" data-target="#myModal" href="#" class="btn px-5 btn-product">КУПИТЬ</a></div>
                    <div class="col-md-6"><a href="/spare-parts" class="btn px-5 btn-product">КУПИТЬ ЗАПЧАСТИ</a></div>
                </div>
			</div>			
		</div>
	</div>
</section>

<section>
	<div class="container">		
		<div class="tabs-for-products">
			<div class="row">
				<div class="col-lg-2 col-dek text-center tabs-for-products-bookmark" style="border-bottom: none;"><h5>DMV</h5></div>
				<div class="col-lg-2 col-dek text-center tabs-for-products-bookmark" style="border-bottom: none; background:black; color:white;"><h5>DMV-D</h5></div>
				<div class="col-lg-2 col-dek text-center tabs-for-products-bookmark" style="border-bottom: none; background:black; color:white;"><h5>DMV-DLE</h5></div>
				<div class="col-lg-2 col-dek text-center tabs-for-products-bookmark" style="border-bottom: none; background:black; color:white;"><h5>DMV-SE</h5></div>
				<div class="col-lg-2 col-dek text-center tabs-for-products-bookmark tabs-for-products-bookmark-right" style="border-bottom: none; background:black; color:white;"><h5>DMV-VEF</h5></div>				
			</div>
			
			
			<!--Первое поле карточки-->
			<div class="tabs-for-products-page p-md-5 py-3" >
				<div class="row">
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-12.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 5065 12</h4>
							<ul>								
								<li>Модель: DMV 5065/12</li>
								<li>Расход газа при перепаде Др=10: 250 м3/час</li>
								<li>Соединение: Dn 65</li>
								<li>Входное давление: 500 мбар</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>						
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-12.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 5080 12</h4>
							<ul>								
								<li>Модель: DMV 5080/12</li>
								<li>Расход газа при перепаде Др=10: 350 м3/час</li>
								<li>Соединение: Dn 80</li>
								<li>Входное давление: 500 мбар</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>						
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-12.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 5100 12</h4>
							<ul>								
								<li>Модель: DMV 5100/12<li>
								<li>Расход газа при перепаде Др=10: 550 м3/час</li>
								<li>Соединение: Dn 100</li>
								<li>Входное давление: 500 мбар</li>								
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>			
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-12.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 525 12</h4>
							<ul>								
								<li>Модель: DMV 525/12</li>
								<li>Расход газа при перепаде Др=10: 150 м3/час</li>
								<li>Соединение: Rp 2′</li>
								<li>Входное давл.: 500 мбар</li>
							</ul><br>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>						
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 5065 11 ECO</h4>
							<ul>								
								<li>Модель: DMV 5065/11 eco</li>
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 170 м3/час</li>
								<li>Соединение: Dn65</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>						
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 5080 11 ECO</h4>
							<ul>								
								<li>Модель: DMV 5080/11 eco</li>
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 260 м3/час</li>
								<li>Соединение: Dn80</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>						
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 5100 11 ECO</h4>
							<ul>								
								<li>Модель: DMV 5100/11 eco</li>
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 380 м3/час</li>
								<li>Соединение: Dn100</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 5125 11 ECO</h4>
							<ul>								
								<li>Модель: DMV 5125/11 eco</li>
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 650 м3/час</li>
								<li>Соединение: Dn125</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV 525 11 ECO</h4>
							<ul>								
								<li>Модель: DMV 525/11 eco</li>
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 145 м3/час</li>
								<li>Соединение: Rp2′ (Dn50)</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
				</div>
			</div>
			<!--Конец первого поля карточки-->


			<!--Второе поле карточки-->
			<div class="tabs-for-products-page p-md-5 py-3" style="display:none;">			
				<div class="row">
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 503 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 6,5 м3/час</li>
								<li>Соединение: Rp 3/8′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 507 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 24 м3/час</li>
								<li>Соединение: Rp 3/4′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">	
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 512 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 68 м3/час</li>
								<li>Соединение: Rp 1 1/4′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">	
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 520 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
								<li>Соединение: Rp 2′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">	
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 525 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 145 м3/час</li>
								<li>Соединение: Rp2′ (Dn50)</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">		
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 5040 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 100 м3/час</li>
								<li>Соединение: DN 40</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 5050 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
								<li>Соединение: DN 50</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 5065 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 170 м3/час</li>
								<li>Соединение: DN 65</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">		
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 5080 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 260 м3/час</li>
								<li>Соединение: DN 80</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">		
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 5100 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 380 м3/час</li>
								<li>Соединение: DN 100</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">
							<img src="img/dmv-d-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-D 5125 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 650 м3/час</li>
								<li>Соединение: DN 125</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
				</div>				
			</div>
			<!--Конец второго поля карточки-->


			<!--Третье поле карточки-->
			<div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
				<div class="row">
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 503 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 6,5 м3/час</li>
								<li>Соединение: Rp 3/8′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 507 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 24 м3/час</li>
								<li>Соединение: Rp 3/4′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 512 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 68 м3/час</li>
								<li>Соединение: Rp 1 1/4′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 520 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
								<li>Соединение: Rp 2′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 525 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 145 м3/час</li>
								<li>Соединение: Rp2′ (Dn50)</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 5040 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 100 м3/час</li>
								<li>Соединение: DN 40</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 5050 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
								<li>Соединение: DN 50</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 5065 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 170 м3/час</li>
								<li>Соединение: DN 65</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 5080 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 260 м3/час</li>
								<li>Соединение: DN 80</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 5100 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 380 м3/час</li>
								<li>Соединение: DN 100</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-dle-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-DLE 5125 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 650 м3/час</li>
								<li>Соединение: DN 125</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
				</div>		
			</div>
			<!--Конец третьего поля карточки-->
			
			<!--Четвертое поле карточки-->
			<div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
				<div class="row">
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-se-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-SE 507 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 24 м3/час</li>
								<li>Соединение: Rp 3/4′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-se-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-SE 512 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 68 м 3 /час</li>
								<li>Соединение: Rp 1 1/4′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-se-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-SE 520 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
								<li>Соединение: Rp 2′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-se-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-SE 5065 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
								<li>Соединение: DN 65</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-se-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-SE 5080 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
								<li>Соединение: DN 80</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-se-11.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-SE 5100 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 110 м3/час</li>
								<li>Соединение: DN 100</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>					
				</div>		
			</div>
			<!--Конец четвертого поля карточки-->
			
			<!--Пятое поле карточки-->
			<div class="tabs-for-products-page p-md-5 py-3" style="display:none;">
				<div class="row">
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-vef.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-VEF 507 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 5-100 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 18 м3/час</li>
								<li>Соединение: Rp 3/4′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-vef.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-VEF 512 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 5-100 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 52 м3/час</li>
								<li>Соединение: Rp 1′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-vef.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-VEF 520 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 5-100 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 75 м3/час</li>
								<li>Соединение: Rp 2′</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-vef.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-VEF 5065 11</h4>
							<ul>								
								<li>Макс. рабочее давление: 100-360 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 130 м3/час</li>
								<li>Соединение: DN 65</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-vef.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-VEF 5080 11</h4>
							<ul>								
								<li>Макс. рабочее давление: до 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 230 м3/час</li>
								<li>Соединение: DN 80</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-vef.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-VEF 5100 11</h4>
							<ul>								
								<li>Макс. рабочее давление: до 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 330 м3/час</li>
								<li>Соединение: DN 100</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
					<div class="col-lg-4 mb-4">
						<div class="products-cart">							
							<img src="img/dmv-vef.png" class="img-fluid" alt="Dungs DMV">
							<h4>DMV-VEF 5125 11</h4>
							<ul>								
								<li>Макс. рабочее давление: до 500 мбар</li>
								<li>Расход газа при перепаде р=10 мбар: 500 м3/час</li>
								<li>Соединение: DN 125</li>
							</ul>
                            <div class="text-center mb-3 for-textarea-footer" data-toggle="modal" data-target="#myModal">Заказать</div>
						</div>							
					</div>
				</div>		
			</div>
			<!--Конец пятого поля карточки-->
			
		</div>
	</div>
</section>

<div class="py-30"></div>

<?php	
	require "footer.php";
?>	